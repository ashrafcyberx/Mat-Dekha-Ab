# Info Finder — Ashraf CyberX (Android source)

## Build APK on GitHub
1. Create a new GitHub repository.
2. Upload all files and folders from this ZIP to the repository root.
3. Open **Actions** → **Build Info Finder APK** → **Run workflow** (or push to `main`).
4. When the workflow completes, open its run and download the `InfoFinder-CyberX-debug-apk` artifact.
5. Extract the artifact ZIP to get `app-debug.apk`.

## Important limitations
- This is an Android WebView wrapper around the supplied HTML, with the access key changed to `CYBERX`, the animated rooftop banner removed, and a welcome message added.
- The Telegram button opens `https://t.me/Ashraf_CyberX`. The app cannot reliably verify that someone has joined a Telegram channel; a client-only “join first” screen is not proof of membership.
- Phone/Aadhaar/account-record lookups are intentionally not wired to a third-party personal-data API. Connect only a backend you control and are authorized to use, with consent and appropriate safeguards.
- A key embedded in HTML/APK can be extracted. `CYBERX` is a convenience gate, not secure authentication. Keep API secrets on a server, never inside the APK.
- This workflow builds a debug APK artifact. A release APK should be signed securely before distribution.
