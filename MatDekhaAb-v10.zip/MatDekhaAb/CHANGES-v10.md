# Mat Dekha Ab v0.9.0 (v10) - "Command" redesign + new logo

## New logo (original artwork)
- Slashed eye (Mat Dekha = don't look) inside a timer ring: red = time used, green = time left.
- Used as the launcher icon, header tile, About screen and the blocked screen.

## Blocked screen
- Opening a blocked app now shows: "MARDE RAHE DA AAJ MAT CHALAWA ARAM KARA" in a big highlighted card,
  with the Mat Dekha Ab wordmark, which app/limit was hit, 5-second auto-close and the cut (X) button.

## Design
- Flat pro cards (18dp), rectangular red buttons, thinner type.
- Home: gauge ring (today vs 7-day average, green/amber/red) + big time + weekly bars.
- Bottom bar: docked, red indicator line over the active tab, icon + label.
