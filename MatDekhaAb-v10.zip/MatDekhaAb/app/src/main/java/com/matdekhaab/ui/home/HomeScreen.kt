package com.matdekhaab.ui.home

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.matdekhaab.domain.DailyTotal
import com.matdekhaab.domain.UsageSummary
import com.matdekhaab.ui.components.*
import com.matdekhaab.ui.formatDuration
import com.matdekhaab.ui.theme.Accent
import com.matdekhaab.ui.theme.Danger
import com.matdekhaab.ui.theme.Line
import com.matdekhaab.ui.theme.Success
import com.matdekhaab.ui.theme.Surface3
import com.matdekhaab.ui.theme.TextMuted
import com.matdekhaab.ui.theme.TextPrimary
import com.matdekhaab.ui.theme.Warning
import java.util.Locale
import kotlin.math.abs
import java.time.format.TextStyle as DayStyle

@Composable
fun HomeScreen(vm: HomeViewModel, onOpenAppBlocker: () -> Unit) {
    val context = LocalContext.current
    val granted by vm.accessGranted.collectAsStateWithLifecycle()
    val total by vm.totalMs.collectAsStateWithLifecycle()
    val top by vm.topApps.collectAsStateWithLifecycle()
    val weekly by vm.weekly.collectAsStateWithLifecycle()
    val trackedCount by vm.trackedCount.collectAsStateWithLifecycle()
    val serviceOn by vm.serviceOn.collectAsStateWithLifecycle()

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item(key = "brand") { BrandHeader("Control your scroll", serviceOn) }

        if (!serviceOn) {
            item(key = "service") { AccessibilityCard() }
        }

        if (!granted) {
            item(key = "usage") {
                StatusBanner(
                    title = "Usage Access needed",
                    body = "To show your screen time, Android requires you to allow Usage Access for this app. " +
                        "It is only read on this device and is never uploaded.",
                    extra = {
                        GradientButton(
                            text = "Grant Usage Access",
                            onClick = { launchFirstResolvable(context, vm.usageSettingsIntents()) },
                            modifier = Modifier.fillMaxWidth(),
                        )
                    },
                )
            }
        }

        item(key = "hero") { HeroCard(total, weekly) }

        item(key = "stats") {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatTile(
                    label = "Daily average · 7 days",
                    value = formatDuration(weekly?.dailyAverageMs ?: 0L),
                    modifier = Modifier.weight(1f),
                    marker = Warning,
                )
                StatTile(
                    label = "Apps guarded",
                    value = trackedCount.toString(),
                    modifier = Modifier.weight(1f),
                    marker = Success,
                )
            }
        }

        item(key = "top-label") { SectionLabel("Most used today") }

        if (top.isEmpty()) {
            item(key = "empty") {
                EmptyHint(if (granted) "No usage recorded yet today." else "Grant Usage Access to see your usage.")
            }
        } else {
            val maxMs = top.maxOf { it.foregroundMs }.coerceAtLeast(1L)
            item(key = "top") {
                AppCard {
                    top.forEachIndexed { index, row ->
                        if (index > 0) Box(Modifier.fillMaxWidth().height(1.dp).background(Line))
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                Text(
                                    "${index + 1}",
                                    color = if (index == 0) Accent else TextMuted,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    modifier = Modifier.width(14.dp),
                                )
                                AppIcon(row.packageName)
                                Column(Modifier.weight(1f)) {
                                    Text(row.label, style = MaterialTheme.typography.titleMedium, maxLines = 1)
                                    Text(
                                        if (row.launchCount == 1) "1 launch" else "${row.launchCount} launches",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    )
                                }
                                Text(
                                    formatDuration(row.foregroundMs),
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MaterialTheme.colorScheme.onSurface,
                                )
                            }
                            MiniBar(
                                progress = row.foregroundMs.toFloat() / maxMs,
                                color = if (index == 0) Accent else Color(0xFF5A606C),
                            )
                        }
                    }
                }
            }
            item(key = "cta") {
                GradientButton(
                    text = "Set limits in App Blocker",
                    onClick = onOpenAppBlocker,
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        }

        item(key = "brand-footer") {
            Text(
                "Control Your Scroll  \u00B7  By Ashraf CyberX",
                style = MaterialTheme.typography.bodySmall,
                color = TextMuted,
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            )
        }
    }
}

@Composable
private fun HeroCard(totalMs: Long, weekly: UsageSummary?) {
    val avgMs = weekly?.dailyAverageMs ?: 0L
    val ratio = if (avgMs > 0L) totalMs.toFloat() / avgMs else 0f
    val tone = when {
        avgMs <= 0L -> TextMuted
        ratio < 0.75f -> Success
        ratio < 1f -> Warning
        else -> Danger
    }
    val message = when {
        avgMs <= 0L -> "Aaj ka hisaab shuru ho gaya."
        ratio < 0.75f -> "Shabash! Aaj control mein ho."
        ratio < 1f -> "Average ke kareeb ho, dhyaan rakho."
        else -> "Average se zyada ho gaya. Mat dekha ab!"
    }
    val delta = when {
        avgMs <= 0L -> "Collecting data"
        ratio >= 1f -> "${abs(((ratio - 1f) * 100).toInt())}% above avg"
        else -> "${abs(((1f - ratio) * 100).toInt())}% below avg"
    }

    AppCard(highlight = true) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(18.dp)) {
            ProgressRing(
                progress = if (avgMs > 0L) ratio else 0f,
                color = tone,
                modifier = Modifier.size(108.dp),
                strokeWidth = 10.dp,
            ) {
                Text(
                    if (avgMs > 0L) "${(ratio * 100).toInt()}%" else "--",
                    fontWeight = FontWeight.Bold,
                    fontSize = 22.sp,
                    color = TextPrimary,
                )
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    "TODAY",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    letterSpacing = 1.4.sp,
                )
                Text(
                    formatDuration(totalMs),
                    style = TextStyle(fontSize = 40.sp, lineHeight = 44.sp, fontWeight = FontWeight.Bold, letterSpacing = (-1.2).sp),
                    color = TextPrimary,
                )
                Pill(delta, tone)
            }
        }
        Text(message, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurface)
        Box(Modifier.fillMaxWidth().height(1.dp).background(Line))
        weekly?.let { WeeklyBars(it.dailyTotals, if (avgMs > 0L) tone else Accent) }
    }
}

@Composable
private fun WeeklyBars(days: List<DailyTotal>, todayColor: Color) {
    val max = (days.maxOfOrNull { it.totalMs } ?: 0L).coerceAtLeast(1L)
    Row(
        Modifier.fillMaxWidth().height(104.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalAlignment = Alignment.Bottom,
    ) {
        days.forEachIndexed { i, d ->
            val isToday = i == days.lastIndex
            Column(
                Modifier.weight(1f).fillMaxHeight(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Bottom,
            ) {
                if (isToday) {
                    Text(
                        formatDuration(d.totalMs),
                        style = MaterialTheme.typography.bodySmall,
                        color = todayColor,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                    )
                    Spacer(Modifier.height(3.dp))
                }
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height((62f * d.totalMs / max).coerceAtLeast(4f).dp)
                        .clip(RoundedCornerShape(5.dp))
                        .background(if (isToday) todayColor else Surface3)
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    d.date.dayOfWeek.getDisplayName(DayStyle.SHORT, Locale.getDefault()),
                    style = MaterialTheme.typography.bodySmall,
                    color = if (isToday) TextPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                )
            }
        }
    }
}

private fun launchFirstResolvable(context: Context, intents: List<Intent>) {
    for (i in intents) {
        try { context.startActivity(i); return } catch (ignored: Exception) { /* try next */ }
    }
}
