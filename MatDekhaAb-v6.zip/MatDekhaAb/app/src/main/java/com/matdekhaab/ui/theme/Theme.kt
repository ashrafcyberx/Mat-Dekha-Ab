package com.matdekhaab.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// Signature palette: pure dark surfaces with gold gradient accents (matches the Ashraf Ali branding).
val Bg = Color(0xFF050506)
val Surface1 = Color(0xFF0E0E11)
val Surface2 = Color(0xFF17171C)
val Surface3 = Color(0xFF23232B)
val Accent = Color(0xFFF5B301)
val AccentLight = Color(0xFFFFD76A)
val AccentDeep = Color(0xFFB8860B)
val Ember = Color(0xFFFFA630)
val OnAccent = Color(0xFF1A1200)
val TextPrimary = Color(0xFFF5F2EA)
val TextMuted = Color(0xFF9A978C)
val Line = Color(0x1AFFFFFF)
val Success = Color(0xFF2EE59D)
val Warning = Color(0xFFFFB84D)
val Danger = Color(0xFFFF5C6C)

/** Condensed bold system face (closest built-in match to Bebas Neue; no font download needed). */
val HeadFont = FontFamily(android.graphics.Typeface.create("sans-serif-condensed", android.graphics.Typeface.BOLD))

val BrandGradient: Brush = Brush.linearGradient(listOf(AccentLight, Accent, AccentDeep))

private val Scheme = darkColorScheme(
    primary = Accent,
    onPrimary = OnAccent,
    primaryContainer = Color(0xFF3A2C00),
    onPrimaryContainer = AccentLight,
    secondary = Ember,
    tertiary = Success,
    background = Bg,
    onBackground = TextPrimary,
    surface = Surface1,
    onSurface = TextPrimary,
    surfaceVariant = Surface2,
    onSurfaceVariant = TextMuted,
    surfaceContainer = Surface1,
    surfaceContainerHigh = Surface2,
    surfaceContainerHighest = Surface3,
    outline = Line,
    outlineVariant = Line,
    error = Danger,
)

private val AppTypography = Typography(
    headlineMedium = TextStyle(fontFamily = HeadFont, fontWeight = FontWeight.Bold, fontSize = 28.sp, lineHeight = 34.sp, letterSpacing = 1.sp),
    titleLarge = TextStyle(fontFamily = HeadFont, fontWeight = FontWeight.Bold, fontSize = 22.sp, lineHeight = 28.sp, letterSpacing = 0.5.sp),
    titleMedium = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 15.sp, lineHeight = 21.sp),
    bodyMedium = TextStyle(fontSize = 14.sp, lineHeight = 20.sp),
    bodySmall = TextStyle(fontSize = 12.sp, lineHeight = 17.sp),
    labelMedium = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 12.sp),
)

private val AppShapes = Shapes(
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(24.dp),
)

@Composable
fun MatDekhaTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, typography = AppTypography, shapes = AppShapes, content = content)
}
