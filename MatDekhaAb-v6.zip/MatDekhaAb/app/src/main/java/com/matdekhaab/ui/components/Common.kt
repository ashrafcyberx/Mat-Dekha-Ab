package com.matdekhaab.ui.components

import android.util.LruCache
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SwitchColors
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import com.matdekhaab.R
import com.matdekhaab.ui.theme.Accent
import com.matdekhaab.ui.theme.AccentLight
import com.matdekhaab.ui.theme.Bg
import com.matdekhaab.ui.theme.Danger
import com.matdekhaab.ui.theme.Ember
import com.matdekhaab.ui.theme.HeadFont
import com.matdekhaab.ui.theme.BrandGradient
import com.matdekhaab.ui.theme.Line
import com.matdekhaab.ui.theme.OnAccent
import com.matdekhaab.ui.theme.Success
import com.matdekhaab.ui.theme.Surface1
import com.matdekhaab.ui.theme.Surface2
import com.matdekhaab.ui.theme.Surface3
import com.matdekhaab.ui.theme.TextMuted
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.PI
import kotlin.math.sin
import kotlin.random.Random

/** Backdrop: near-black, soft gold glow and a few slow floating gold particles (12 dots = cheap). */
@Composable
fun AppBackground(content: @Composable BoxScope.() -> Unit) {
    // x, y, size factor, speed (whole numbers so the loop is seamless)
    val seeds = remember {
        List(12) { floatArrayOf(Random.nextFloat(), Random.nextFloat(), 0.5f + Random.nextFloat(), if (it % 3 == 0) 2f else 1f) }
    }
    val t by rememberInfiniteTransition(label = "particles").animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(26000, easing = LinearEasing), RepeatMode.Restart),
        label = "t",
    )
    Box(
        Modifier
            .fillMaxSize()
            .background(Bg)
            .drawBehind {
                drawRect(
                    Brush.radialGradient(
                        colors = listOf(Accent.copy(alpha = 0.18f), Color.Transparent),
                        center = Offset(size.width * 0.95f, 0f),
                        radius = size.width * 1.0f,
                    )
                )
                drawRect(
                    Brush.radialGradient(
                        colors = listOf(Ember.copy(alpha = 0.07f), Color.Transparent),
                        center = Offset(0f, size.height * 0.7f),
                        radius = size.width * 0.9f,
                    )
                )
                val sway = 14.dp.toPx()
                seeds.forEach { p ->
                    val y = (((p[1] - t * p[3] * 0.5f) % 1f) + 1f) % 1f
                    val x = p[0] * size.width + sin((t * 2f * PI.toFloat()) + p[1] * 6f) * sway
                    drawCircle(
                        color = AccentLight.copy(alpha = 0.10f + 0.22f * p[2].coerceAtMost(1f)),
                        radius = (1.2f + 1.6f * p[2]).dp.toPx(),
                        center = Offset(x, y * size.height),
                    )
                }
            },
        content = content,
    )
}

@Composable
fun ScreenHeader(title: String, subtitle: String) {
    Column(Modifier.padding(top = 8.dp, bottom = 2.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(title, style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.onBackground)
        Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

/** App logo cropped to the phone + timer artwork, inside a slowly spinning gold ring. */
@Composable
fun LogoMark(size: Dp, modifier: Modifier = Modifier) {
    val spin = rememberInfiniteTransition(label = "logo-ring")
    val angle by spin.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(4200, easing = LinearEasing), RepeatMode.Restart),
        label = "angle",
    )
    val shape = RoundedCornerShape(size * 0.3f)
    Box(
        modifier
            .size(size + 12.dp)
            .drawBehind {
                val stroke = 3.dp.toPx()
                rotate(angle) {
                    drawCircle(
                        brush = Brush.sweepGradient(listOf(Color.Transparent, Accent, AccentLight, Color.Transparent)),
                        radius = this.size.minDimension / 2 - stroke / 2,
                        style = Stroke(width = stroke),
                    )
                }
            }
            .padding(6.dp),
        contentAlignment = Alignment.Center,
    ) {
        Box(
            Modifier
                .fillMaxSize()
                .clip(shape)
                .background(Color(0xFF020308))
                .border(1.dp, Brush.linearGradient(listOf(Accent.copy(alpha = 0.8f), Color(0x22FFFFFF))), shape),
        ) {
            Image(
                painter = painterResource(R.drawable.ic_logo),
                contentDescription = "Mat Dekha Ab logo",
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        scaleX = 1.7f
                        scaleY = 1.7f
                        transformOrigin = TransformOrigin(0.5f, 0.33f)
                    },
            )
        }
    }
}

@Composable
fun BrandHeader(subtitle: String, serviceOn: Boolean) {
    Row(
        Modifier.padding(top = 8.dp, bottom = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        LogoMark(56.dp)
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(
                buildAnnotatedString {
                    append("MAT ")
                    withStyle(SpanStyle(color = Accent)) { append("DEKHA") }
                    append(" AB")
                },
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.onBackground,
            )
            Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        StatusChip(serviceOn)
    }
}

@Composable
fun StatusChip(on: Boolean) {
    val color = if (on) Success else Danger
    Row(
        Modifier
            .clip(CircleShape)
            .background(color.copy(alpha = 0.14f))
            .border(1.dp, color.copy(alpha = 0.35f), CircleShape)
            .padding(horizontal = 10.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Box(Modifier.size(7.dp).clip(CircleShape).background(color))
        Text(if (on) "Blocker ON" else "Blocker OFF", style = MaterialTheme.typography.labelMedium, color = color)
    }
}

@Composable
fun SectionLabel(text: String) {
    Row(
        Modifier.padding(top = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Box(Modifier.width(3.dp).height(14.dp).clip(CircleShape).background(BrandGradient))
        Text(
            text.uppercase(),
            style = MaterialTheme.typography.labelMedium,
            color = TextMuted,
            letterSpacing = 1.2.sp,
        )
    }
}

/** Glass-style card. [highlight] adds a red-tinted border for hero content. */
@Composable
fun AppCard(
    modifier: Modifier = Modifier,
    highlight: Boolean = false,
    content: @Composable ColumnScope.() -> Unit,
) {
    val shape = RoundedCornerShape(22.dp)
    val fill = if (highlight) {
        Brush.verticalGradient(listOf(Accent.copy(alpha = 0.14f), Color(0x0DFFFFFF)))
    } else {
        Brush.verticalGradient(listOf(Color(0x14FFFFFF), Color(0x08FFFFFF)))
    }
    val border = if (highlight) {
        Brush.verticalGradient(listOf(Accent.copy(alpha = 0.75f), Accent.copy(alpha = 0.10f)))
    } else {
        Brush.verticalGradient(listOf(Color(0x33FFFFFF), Color(0x0AFFFFFF)))
    }
    Column(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(fill)
            .border(1.dp, border, shape)
            .then(modifier)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        content = content,
    )
}

@Composable
fun StatTile(label: String, value: String, modifier: Modifier = Modifier, emoji: String = "") {
    AppCard(modifier) {
        if (emoji.isNotEmpty()) Text(emoji, fontSize = 20.sp)
        Text(value, style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.onSurface)
        Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun StatusBanner(
    title: String,
    body: String,
    modifier: Modifier = Modifier,
    extra: (@Composable ColumnScope.() -> Unit)? = null,
) {
    val shape = RoundedCornerShape(20.dp)
    Column(
        modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Brush.linearGradient(listOf(Accent.copy(alpha = 0.16f), Accent.copy(alpha = 0.04f))))
            .border(1.dp, Accent.copy(alpha = 0.35f), shape)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(Icons.Filled.Info, contentDescription = null, tint = Accent, modifier = Modifier.size(18.dp))
            Text(title, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurface)
        }
        Text(body, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.85f))
        extra?.invoke(this)
    }
}

@Composable
fun GradientButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(16.dp)
    val sweep = rememberInfiniteTransition(label = "shimmer")
    val pos by sweep.animateFloat(
        initialValue = -0.3f,
        targetValue = 1.3f,
        animationSpec = infiniteRepeatable(tween(2600, easing = LinearEasing), RepeatMode.Restart),
        label = "pos",
    )
    Box(
        modifier
            .height(52.dp)
            .clip(shape)
            .background(BrandGradient)
            .drawBehind {
                val x = size.width * pos
                drawRect(
                    Brush.horizontalGradient(
                        colors = listOf(Color.Transparent, Color.White.copy(alpha = 0.35f), Color.Transparent),
                        startX = x - size.width * 0.18f,
                        endX = x + size.width * 0.18f,
                    )
                )
            }
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text.uppercase(),
            color = OnAccent,
            fontFamily = HeadFont,
            fontWeight = FontWeight.Bold,
            fontSize = 16.sp,
            letterSpacing = 1.sp,
            modifier = Modifier.padding(horizontal = 20.dp),
        )
    }
}

@Composable
fun GhostButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(12.dp)
    Box(
        modifier
            .height(42.dp)
            .clip(shape)
            .background(Surface3)
            .border(1.dp, Line, shape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text,
            color = MaterialTheme.colorScheme.onSurface,
            fontWeight = FontWeight.SemiBold,
            fontSize = 14.sp,
            modifier = Modifier.padding(horizontal = 16.dp),
        )
    }
}

@Composable
fun appSwitchColors(): SwitchColors = SwitchDefaults.colors(
    checkedThumbColor = OnAccent,
    checkedTrackColor = Accent,
    uncheckedThumbColor = TextMuted,
    uncheckedTrackColor = Surface3,
    uncheckedBorderColor = Line,
)

/** Circular progress ring (animated sweep). Content is drawn in the middle. */
@Composable
fun ProgressRing(
    progress: Float,
    color: Color,
    modifier: Modifier = Modifier,
    strokeWidth: Dp = 12.dp,
    content: @Composable BoxScope.() -> Unit,
) {
    val animated by animateFloatAsState(
        targetValue = progress.coerceIn(0f, 1f),
        animationSpec = tween(900),
        label = "ring",
    )
    Box(
        modifier.drawBehind {
            val sw = strokeWidth.toPx()
            val topLeft = Offset(sw / 2, sw / 2)
            val arc = Size(size.width - sw, size.height - sw)
            drawArc(
                color = Color.White.copy(alpha = 0.07f),
                startAngle = -90f,
                sweepAngle = 360f,
                useCenter = false,
                topLeft = topLeft,
                size = arc,
                style = Stroke(width = sw, cap = StrokeCap.Round),
            )
            if (animated > 0.005f) {
                drawArc(
                    color = color,
                    startAngle = -90f,
                    sweepAngle = 360f * animated,
                    useCenter = false,
                    topLeft = topLeft,
                    size = arc,
                    style = Stroke(width = sw, cap = StrokeCap.Round),
                )
            }
        },
        contentAlignment = Alignment.Center,
        content = content,
    )
}

@Composable
fun MiniBar(progress: Float, color: Color, modifier: Modifier = Modifier) {
    Box(modifier.fillMaxWidth().height(6.dp).clip(CircleShape).background(Surface3)) {
        Box(
            Modifier
                .fillMaxWidth(progress.coerceIn(0f, 1f))
                .fillMaxHeight()
                .clip(CircleShape)
                .background(color)
        )
    }
}

@Composable
fun Pill(text: String, color: Color = Accent) {
    Box(
        Modifier
            .clip(CircleShape)
            .background(color.copy(alpha = 0.15f))
            .padding(horizontal = 10.dp, vertical = 4.dp)
    ) {
        Text(text, style = MaterialTheme.typography.labelMedium, color = color)
    }
}

@Composable
fun EmptyHint(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.fillMaxWidth().padding(vertical = 20.dp),
    )
}

// Icons are decoded once and reused while scrolling, which keeps long app lists smooth.
private val iconCache = LruCache<String, ImageBitmap>(160)

@Composable
fun AppIcon(packageName: String, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val bitmap by produceState<ImageBitmap?>(iconCache.get(packageName), packageName) {
        if (value == null) {
            value = withContext(Dispatchers.IO) {
                runCatching {
                    context.packageManager.getApplicationIcon(packageName).toBitmap(96, 96).asImageBitmap()
                }.getOrNull()
            }?.also { iconCache.put(packageName, it) }
        }
    }
    Box(modifier.size(42.dp).clip(RoundedCornerShape(12.dp)).background(Surface2)) {
        bitmap?.let { Image(it, contentDescription = null, modifier = Modifier.fillMaxSize()) }
    }
}

@Composable
fun BadgeText(text: String, modifier: Modifier = Modifier, color: Color = Accent) {
    Box(
        modifier.size(38.dp).clip(RoundedCornerShape(11.dp)).background(color.copy(alpha = 0.16f)),
        contentAlignment = Alignment.Center,
    ) {
        Text(text, color = color, fontWeight = FontWeight.ExtraBold, fontSize = 12.sp)
    }
}
