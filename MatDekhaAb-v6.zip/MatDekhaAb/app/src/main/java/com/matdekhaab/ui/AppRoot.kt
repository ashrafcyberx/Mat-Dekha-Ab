package com.matdekhaab.ui

import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.viewmodel.compose.viewModel
import com.matdekhaab.MatDekhaApp
import com.matdekhaab.ui.about.AboutScreen
import com.matdekhaab.ui.apps.AppsScreen
import com.matdekhaab.ui.components.AppBackground
import com.matdekhaab.ui.home.HomeScreen
import com.matdekhaab.ui.home.HomeViewModel
import com.matdekhaab.ui.reels.ReelsScreen
import com.matdekhaab.ui.theme.Accent
import com.matdekhaab.ui.theme.BrandGradient
import com.matdekhaab.ui.theme.HeadFont
import com.matdekhaab.ui.theme.OnAccent
import com.matdekhaab.ui.theme.TextMuted

private enum class Tab(val label: String, val icon: ImageVector) {
    Home("Home", Icons.Filled.Home),
    Reels("Reels", Icons.Filled.PlayArrow),
    Apps("Apps", Icons.AutoMirrored.Filled.List),
    About("About", Icons.Filled.Info),
}

@Composable
fun AppRoot() {
    val container = (LocalContext.current.applicationContext as MatDekhaApp).container
    val factory = remember { VmFactory(container) }
    val home: HomeViewModel = viewModel(factory = factory)
    var tab by rememberSaveable { mutableStateOf(Tab.Home) }

    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { home.refresh() }

    AppBackground {
        Scaffold(
            containerColor = Color.Transparent,
            bottomBar = {
                FloatingNav(selected = tab, onSelect = { tab = it })
            },
        ) { padding ->
            Box(Modifier.padding(padding)) {
                Crossfade(targetState = tab, animationSpec = tween(160), label = "tabs") { current ->
                    when (current) {
                        Tab.Home -> HomeScreen(home, onOpenAppBlocker = { tab = Tab.Apps })
                        Tab.Reels -> ReelsScreen(viewModel(factory = factory), onOpenAppBlocker = { tab = Tab.Apps })
                        Tab.Apps -> AppsScreen(viewModel(factory = factory))
                        Tab.About -> AboutScreen(viewModel(factory = factory))
                    }
                }
            }
        }
    }
}

/** Floating glass pill navigation: the selected tab fills with the gold gradient. */
@Composable
private fun FloatingNav(selected: Tab, onSelect: (Tab) -> Unit) {
    Box(Modifier.navigationBarsPadding().padding(horizontal = 18.dp, vertical = 10.dp)) {
        Row(
            Modifier
                .fillMaxWidth()
                .clip(CircleShape)
                .background(Color(0xEB101014))
                .border(1.dp, Accent.copy(alpha = 0.35f), CircleShape)
                .padding(6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Tab.entries.forEach { t ->
                val on = t == selected
                Row(
                    Modifier
                        .clip(CircleShape)
                        .then(if (on) Modifier.background(BrandGradient) else Modifier)
                        .clickable { onSelect(t) }
                        .padding(horizontal = if (on) 16.dp else 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    Icon(t.icon, contentDescription = t.label, tint = if (on) OnAccent else TextMuted, modifier = Modifier.size(22.dp))
                    if (on) {
                        Text(t.label.uppercase(), color = OnAccent, fontFamily = HeadFont, fontWeight = FontWeight.Bold, fontSize = 14.sp, letterSpacing = 1.sp)
                    }
                }
            }
        }
    }
}
