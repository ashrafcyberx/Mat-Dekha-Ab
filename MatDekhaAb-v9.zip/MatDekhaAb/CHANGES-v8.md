# Mat Dekha Ab v0.7.0 (v8) - permission gate

- New full-screen "Allow permissions" screen on launch. The app does NOT open until both are allowed:
  1. Usage Access  2. Blocking (Accessibility) service
- Tapping "Allow" shows a short popup explaining what the permission is used for, then opens the right Android settings page.
- Progress bar (0/1/2 of 2 allowed), green tick on each allowed step, "Open App info" shortcut for the greyed-out
  switch on Android 13+ (Allow restricted settings).
- Gate re-checks every time you come back to the app, and appears again if a permission is later switched off.
- Accessibility state is read from Android settings as well as the live service, so there is no flicker at cold start.
- Compact app rows in the Apps tab.
