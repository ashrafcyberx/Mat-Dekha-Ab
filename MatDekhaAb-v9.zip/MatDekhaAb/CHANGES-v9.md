# Mat Dekha Ab v0.8.0 (v9) - "Bento" redesign + branded blocked screen

## Blocked screen (completely new)
- Big "Mat Dekha Ab" wordmark + logo, "BLOCKED" tag, which app is blocked and why, a motivational line.
- Cut button (X, top right) closes it instantly and takes you Home.
- Automatic cut: 5-second countdown ring, then it closes itself and goes Home. "Close now" button too.
  The timer pauses if you leave the screen and restarts on every new block.
- Branding footer: "By Ashraf CyberX - Control Your Scroll".

## New design
- Bigger rounded bento cards, softer gradient surfaces, bolder headings.
- Home hero card changes colour with your day: green (in control), amber (near average), red (over average).
- Floating rounded navigation bar: active tab expands into a red capsule with its label.
- Red gradient primary buttons; brand line at the bottom of Home.
