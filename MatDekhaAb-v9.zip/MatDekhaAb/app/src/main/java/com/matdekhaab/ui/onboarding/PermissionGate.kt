package com.matdekhaab.ui.onboarding

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.matdekhaab.ui.components.AppCard
import com.matdekhaab.ui.components.GhostButton
import com.matdekhaab.ui.components.GradientButton
import com.matdekhaab.ui.components.LogoMark
import com.matdekhaab.ui.components.Pill
import com.matdekhaab.ui.theme.Accent
import com.matdekhaab.ui.theme.Success
import com.matdekhaab.ui.theme.Surface1
import com.matdekhaab.ui.theme.Surface3
import com.matdekhaab.ui.theme.TextMuted
import com.matdekhaab.ui.theme.TextPrimary

private enum class Step { Usage, Accessibility }

/**
 * Full-screen gate shown until BOTH permissions are allowed. Tapping "Allow" first shows a short
 * disclosure popup (what the permission is used for), then sends the user to the right Android settings page.
 */
@Composable
fun PermissionGate(
    usageGranted: Boolean,
    accessibilityOn: Boolean,
    onAllowUsage: () -> Unit,
    onAllowAccessibility: () -> Unit,
    onOpenAppInfo: () -> Unit,
) {
    var pending by remember { mutableStateOf<Step?>(null) }
    val doneCount = (if (usageGranted) 1 else 0) + (if (accessibilityOn) 1 else 0)
    val next = when {
        !usageGranted -> Step.Usage
        !accessibilityOn -> Step.Accessibility
        else -> null
    }

    Column(
        Modifier
            .fillMaxSize()
            .systemBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Spacer(Modifier.height(8.dp))
        LogoMark(72.dp)
        Text("Allow permissions", style = MaterialTheme.typography.headlineMedium)
        Text(
            "Mat Dekha Ab needs two Android permissions to work. The app opens as soon as both are allowed.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            repeat(2) { i ->
                Box(
                    Modifier
                        .weight(1f)
                        .height(4.dp)
                        .clip(CircleShape)
                        .background(if (i < doneCount) Success else Surface3)
                )
            }
        }
        Text("$doneCount of 2 allowed", style = MaterialTheme.typography.labelMedium, color = TextMuted)

        PermissionCard(
            number = 1,
            title = "Usage Access",
            body = "Lets the app measure how long you spend in each app, so it can show your screen time and apply daily limits. " +
                "It is read on this device only and never uploaded.",
            done = usageGranted,
            primary = next == Step.Usage,
            onAllow = { pending = Step.Usage },
        )
        PermissionCard(
            number = 2,
            title = "Blocking service",
            body = "Uses Android's Accessibility service to see which app is open, close it when your limit is reached, " +
                "and spot Reels/Shorts. It does not read messages, passwords or typed text.",
            done = accessibilityOn,
            primary = next == Step.Accessibility,
            onAllow = { pending = Step.Accessibility },
            extra = {
                TextButton(onClick = onOpenAppInfo) {
                    Text("Switch greyed out? Open App info", color = TextMuted, fontSize = 12.sp)
                }
            },
        )

        Text(
            "Everything stays on this device. Mat Dekha Ab has no internet permission.",
            style = MaterialTheme.typography.bodySmall,
            color = TextMuted,
            modifier = Modifier.padding(top = 4.dp),
        )
    }

    pending?.let { step ->
        val isUsage = step == Step.Usage
        AlertDialog(
            onDismissRequest = { pending = null },
            containerColor = Surface1,
            shape = RoundedCornerShape(24.dp),
            title = { Text(if (isUsage) "Allow Usage Access" else "Turn on blocking service") },
            text = {
                Text(
                    if (isUsage) {
                        "Android will open the Usage Access page. Find Mat Dekha Ab in the list, switch it on, then press Back to return here."
                    } else {
                        "Android will open the Accessibility page. Find Mat Dekha Ab under Installed or Downloaded apps and switch it on, then press Back to return here.\n\n" +
                            "If the switch is greyed out (Android 13+): App info → ⋮ menu → Allow restricted settings, then try again."
                    }
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    pending = null
                    if (isUsage) onAllowUsage() else onAllowAccessibility()
                }) { Text("Continue", color = Accent, fontWeight = FontWeight.SemiBold) }
            },
            dismissButton = {
                TextButton(onClick = { pending = null }) { Text("Not now", color = TextMuted) }
            },
        )
    }
}

@Composable
private fun PermissionCard(
    number: Int,
    title: String,
    body: String,
    done: Boolean,
    primary: Boolean,
    onAllow: () -> Unit,
    extra: (@Composable () -> Unit)? = null,
) {
    AppCard(highlight = primary && !done) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(
                Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(if (done) Success.copy(alpha = 0.16f) else Surface3),
                contentAlignment = Alignment.Center,
            ) {
                if (done) {
                    Icon(Icons.Filled.Check, contentDescription = null, tint = Success, modifier = Modifier.size(18.dp))
                } else {
                    Text("$number", fontWeight = FontWeight.Bold, color = TextPrimary, fontSize = 14.sp)
                }
            }
            Text(title, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
            Pill(if (done) "Allowed" else "Required", if (done) Success else Accent)
        }
        Text(body, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (!done) {
            if (primary) GradientButton("Allow", onAllow, Modifier.fillMaxWidth())
            else GhostButton("Allow", onAllow, Modifier.fillMaxWidth())
            extra?.invoke()
        }
    }
}
