package com.matdekhaab.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.viewmodel.compose.viewModel
import com.matdekhaab.MatDekhaApp
import com.matdekhaab.ui.about.AboutScreen
import com.matdekhaab.ui.apps.AppsScreen
import com.matdekhaab.ui.components.AppBackground
import com.matdekhaab.ui.home.HomeScreen
import com.matdekhaab.ui.home.HomeViewModel
import com.matdekhaab.ui.onboarding.PermissionGate
import com.matdekhaab.ui.onboarding.isAccessibilityServiceEnabled
import com.matdekhaab.service.BlockerService
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.matdekhaab.ui.reels.ReelsScreen
import com.matdekhaab.ui.theme.Accent
import com.matdekhaab.ui.theme.Line
import com.matdekhaab.ui.theme.TextMuted
import com.matdekhaab.ui.theme.TextPrimary

private enum class Tab(val label: String, val icon: ImageVector) {
    Home("Home", Icons.Filled.Home),
    Reels("Reels", Icons.Filled.PlayArrow),
    Apps("Apps", Icons.AutoMirrored.Filled.List),
    About("About", Icons.Filled.Info),
}

@Composable
fun AppRoot() {
    val context = LocalContext.current
    val container = (context.applicationContext as MatDekhaApp).container
    val factory = remember { VmFactory(container) }
    val home: HomeViewModel = viewModel(factory = factory)
    var tab by rememberSaveable { mutableStateOf(Tab.Home) }

    val usageGranted by container.usageAccess.granted.collectAsStateWithLifecycle()
    val serviceConnected by BlockerService.connected.collectAsStateWithLifecycle()
    var accessibilitySetting by remember { mutableStateOf(isAccessibilityServiceEnabled(context)) }
    val ready = usageGranted && (accessibilitySetting || serviceConnected)

    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        home.refresh()
        accessibilitySetting = isAccessibilityServiceEnabled(context)
    }

    AppBackground {
        Crossfade(targetState = ready, animationSpec = tween(220), label = "gate") { isReady ->
            if (!isReady) {
                PermissionGate(
                    usageGranted = usageGranted,
                    accessibilityOn = accessibilitySetting || serviceConnected,
                    onAllowUsage = { launchFirstResolvable(context, container.usageAccess.settingsIntents()) },
                    onAllowAccessibility = {
                        launchFirstResolvable(
                            context,
                            listOf(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)),
                        )
                    },
                    onOpenAppInfo = {
                        launchFirstResolvable(
                            context,
                            listOf(
                                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}"))
                                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            ),
                        )
                    },
                )
            } else {
                Scaffold(
                    containerColor = Color.Transparent,
                    bottomBar = { FloatingNav(selected = tab, onSelect = { tab = it }) },
                ) { padding ->
                    Box(Modifier.padding(padding)) {
                        Crossfade(targetState = tab, animationSpec = tween(160), label = "tabs") { current ->
                            when (current) {
                                Tab.Home -> HomeScreen(home, onOpenAppBlocker = { tab = Tab.Apps })
                                Tab.Reels -> ReelsScreen(viewModel(factory = factory), onOpenAppBlocker = { tab = Tab.Apps })
                                Tab.Apps -> AppsScreen(viewModel(factory = factory))
                                Tab.About -> AboutScreen(viewModel(factory = factory))
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun launchFirstResolvable(context: Context, intents: List<Intent>) {
    for (i in intents) {
        try { context.startActivity(i); return } catch (ignored: Exception) { /* try next */ }
    }
}

/** Floating rounded bar: the active tab expands into a red capsule with its label, others show just the icon. */
@Composable
private fun FloatingNav(selected: Tab, onSelect: (Tab) -> Unit) {
    val shape = RoundedCornerShape(30.dp)
    Box(Modifier.navigationBarsPadding().padding(horizontal = 16.dp, vertical = 10.dp)) {
        Row(
            Modifier
                .fillMaxWidth()
                .clip(shape)
                .background(Color(0xF2161920))
                .border(1.dp, Line, shape)
                .padding(6.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Tab.entries.forEach { t ->
                val on = t == selected
                Row(
                    Modifier
                        .weight(if (on) 2.2f else 1f)
                        .height(48.dp)
                        .clip(RoundedCornerShape(24.dp))
                        .background(if (on) Accent else Color.Transparent)
                        .clickable { onSelect(t) },
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(t.icon, contentDescription = t.label, tint = if (on) Color.White else TextMuted, modifier = Modifier.size(22.dp))
                    if (on) {
                        Spacer(Modifier.width(6.dp))
                        Text(t.label, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, maxLines = 1)
                    }
                }
            }
        }
    }
}
