package com.matdekhaab.service

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.setContent
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.repeatOnLifecycle
import com.matdekhaab.MainActivity
import com.matdekhaab.ui.about.DeveloperInfo
import com.matdekhaab.ui.components.AppBackground
import com.matdekhaab.ui.components.AppCard
import com.matdekhaab.ui.components.GradientButton
import com.matdekhaab.ui.components.LogoMark
import com.matdekhaab.ui.components.Pill
import com.matdekhaab.ui.components.ProgressRing
import com.matdekhaab.ui.theme.Accent
import com.matdekhaab.ui.theme.Danger
import com.matdekhaab.ui.theme.Line
import com.matdekhaab.ui.theme.MatDekhaTheme
import com.matdekhaab.ui.theme.Surface2
import com.matdekhaab.ui.theme.TextMuted
import com.matdekhaab.ui.theme.TextPrimary
import kotlinx.coroutines.delay

/**
 * Shown when a limit/blocker triggers. Branded "Mat Dekha Ab" screen that closes itself after a few seconds
 * (back to the Home screen) and has a cut (X) button to close it right away.
 */
class BlockedActivity : ComponentActivity() {

    // Held as Compose state so a second block (singleTask re-delivery) updates the visible text.
    private var blockTitle by mutableStateOf("Blocked")
    private var blockMessage by mutableStateOf("")
    private var blockStamp by mutableLongStateOf(0L) // changes on every block, restarts the auto-close timer

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        readExtras(intent)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() = goHome()
        })

        setContent {
            MatDekhaTheme {
                AppBackground {
                    BlockedScreen(
                        title = blockTitle,
                        message = blockMessage,
                        stamp = blockStamp,
                        lifecycle = lifecycle,
                        onHome = { goHome() },
                        onOpenApp = { openApp() },
                        onTurnOff = { openAccessibilitySettings() },
                    )
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        readExtras(intent)
    }

    private fun readExtras(i: Intent?) {
        blockTitle = i?.getStringExtra(EXTRA_TITLE) ?: "Blocked"
        blockMessage = i?.getStringExtra(EXTRA_MESSAGE) ?: ""
        blockStamp = System.nanoTime()
    }

    private fun goHome() {
        startActivity(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        finishAndRemoveTask()
    }

    private fun openApp() {
        startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        finishAndRemoveTask()
    }

    private fun openAccessibilitySettings() {
        runCatching {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        finishAndRemoveTask()
    }

    companion object {
        const val EXTRA_TITLE = "title"
        const val EXTRA_MESSAGE = "message"
    }
}

private const val AUTO_CLOSE_SECONDS = 5

private val Nudges = listOf(
    "Ye time tera hai. Kuch bana, kuch seekh.",
    "Scroll kam, kaam zyada. Tu isse bada hai!",
    "Phone rakh, duniya dekh. Real life zyada mast hai.",
    "Ek minute ruk. Kya sach mein isi ke liye aaya tha?",
)

@Composable
private fun BlockedScreen(
    title: String,
    message: String,
    stamp: Long,
    lifecycle: Lifecycle,
    onHome: () -> Unit,
    onOpenApp: () -> Unit,
    onTurnOff: () -> Unit,
) {
    val nudge = remember(title, message) { Nudges[(title + message).hashCode().mod(Nudges.size)] }
    var left by remember(stamp) { mutableIntStateOf(AUTO_CLOSE_SECONDS) }

    // Automatic cut: counts down while the screen is visible, then goes Home. Pauses if the user leaves.
    LaunchedEffect(stamp) {
        lifecycle.repeatOnLifecycle(Lifecycle.State.RESUMED) {
            left = AUTO_CLOSE_SECONDS
            while (left > 0) {
                delay(1000)
                left--
            }
            onHome()
        }
    }

    val pulse = rememberInfiniteTransition(label = "pulse")
    val scale by pulse.animateFloat(
        initialValue = 1f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(tween(1400, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "scale",
    )

    Box(Modifier.fillMaxSize().systemBarsPadding()) {
        Column(
            Modifier.fillMaxSize().padding(horizontal = 22.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            // Top bar: brand on the left, cut (X) on the right.
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    LogoMark(30.dp)
                    Text("Mat Dekha Ab", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                }
                Box(
                    Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(Surface2)
                        .border(1.dp, Line, CircleShape)
                        .clickable(onClick = onHome),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(Icons.Filled.Close, contentDescription = "Close", tint = TextPrimary, modifier = Modifier.size(22.dp))
                }
            }

            Column(
                Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(14.dp, Alignment.CenterVertically),
            ) {
                Box(
                    Modifier
                        .size(190.dp)
                        .graphicsLayer { scaleX = scale; scaleY = scale }
                        .clip(CircleShape)
                        .background(Brush.radialGradient(listOf(Accent.copy(alpha = 0.30f), Color.Transparent))),
                    contentAlignment = Alignment.Center,
                ) {
                    LogoMark(120.dp)
                }

                Text(
                    buildAnnotatedString {
                        append("Mat ")
                        withStyle(SpanStyle(color = Accent)) { append("Dekha") }
                        append(" Ab")
                    },
                    fontSize = 38.sp,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = (-1).sp,
                    color = TextPrimary,
                )
                Pill("BLOCKED", Danger)
                Text(
                    title,
                    style = MaterialTheme.typography.titleLarge,
                    textAlign = TextAlign.Center,
                    color = TextPrimary,
                )
                Text(
                    message,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                )
                Text(
                    nudge,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Accent,
                    textAlign = TextAlign.Center,
                )

                AppCard {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                        ProgressRing(
                            progress = left.toFloat() / AUTO_CLOSE_SECONDS,
                            color = Accent,
                            modifier = Modifier.size(52.dp),
                            strokeWidth = 4.dp,
                        ) {
                            Text("$left", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = TextPrimary)
                        }
                        Column(Modifier.weight(1f)) {
                            Text("Closing automatically", style = MaterialTheme.typography.titleMedium)
                            Text(
                                "Taking you Home in ${left}s",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                    GradientButton("Close now", onHome, Modifier.fillMaxWidth())
                }

                TextButton(onClick = onOpenApp) { Text("Open Mat Dekha Ab", color = Accent) }
                TextButton(onClick = onTurnOff) {
                    Text("Turn off blocking (Accessibility settings)", color = TextMuted, fontSize = 12.sp)
                }
            }

            // Branding footer
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(Modifier.weight(1f).height(1.dp).background(Line))
                Text("By ${DeveloperInfo.BRAND}", style = MaterialTheme.typography.labelMedium, color = TextMuted, letterSpacing = 1.sp)
                Box(Modifier.weight(1f).height(1.dp).background(Line))
            }
            Text(
                "Control Your Scroll",
                style = MaterialTheme.typography.bodySmall,
                color = TextMuted,
                modifier = Modifier.padding(top = 6.dp, bottom = 4.dp),
            )
        }
    }
}
