package com.matdekhaab.ui.onboarding

import android.content.ComponentName
import android.content.Context
import android.provider.Settings
import com.matdekhaab.service.BlockerService

/** True when the user has switched the blocking (Accessibility) service on in Android settings. */
fun isAccessibilityServiceEnabled(context: Context): Boolean {
    val resolver = context.contentResolver
    if (Settings.Secure.getInt(resolver, Settings.Secure.ACCESSIBILITY_ENABLED, 0) != 1) return false
    val enabled = Settings.Secure.getString(resolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
    val me = ComponentName(context, BlockerService::class.java)
    return enabled.split(':').any { ComponentName.unflattenFromString(it) == me }
}
