package com.matdekhaab.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// "Bento" design system (v9), taken straight from the logo: ink black, signal red, clean white, mint green.
// Big rounded bento tiles, state-coloured hero, hairline borders. Red = brand / primary action, green = healthy / enabled.
val Bg = Color(0xFF07080B)
val Surface1 = Color(0xFF0F1115)
val Surface2 = Color(0xFF171A21)
val Surface3 = Color(0xFF22262E)
val Accent = Color(0xFFFF2D3F)
val AccentLight = Color(0xFFFF6B77)
val AccentDeep = Color(0xFFC4121F)
val Ember = Color(0xFFFF8A3D)
val OnAccent = Color(0xFFFFFFFF)
val TextPrimary = Color(0xFFF4F5F7)
val TextMuted = Color(0xFF8C919C)
val Line = Color(0x1FFFFFFF)
val Success = Color(0xFF19D38A)
val Warning = Color(0xFFFFB020)
val Danger = Color(0xFFFF4D5E)

/** Kept as an alias so older call sites compile; the new look uses the regular sans-serif everywhere. */
val HeadFont: FontFamily = FontFamily.SansSerif

val BrandGradient: Brush = Brush.linearGradient(listOf(Accent, AccentDeep))

private val Scheme = darkColorScheme(
    primary = Accent,
    onPrimary = OnAccent,
    primaryContainer = Color(0xFF3A0D12),
    onPrimaryContainer = AccentLight,
    secondary = Ember,
    tertiary = Success,
    background = Bg,
    onBackground = TextPrimary,
    surface = Surface1,
    onSurface = TextPrimary,
    surfaceVariant = Surface2,
    onSurfaceVariant = TextMuted,
    surfaceContainer = Surface1,
    surfaceContainerHigh = Surface2,
    surfaceContainerHighest = Surface3,
    outline = Line,
    outlineVariant = Line,
    error = Danger,
)

private val AppTypography = Typography(
    headlineMedium = TextStyle(fontWeight = FontWeight.Bold, fontSize = 30.sp, lineHeight = 36.sp, letterSpacing = (-0.8).sp),
    titleLarge = TextStyle(fontWeight = FontWeight.Bold, fontSize = 20.sp, lineHeight = 26.sp, letterSpacing = (-0.2).sp),
    titleMedium = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 15.sp, lineHeight = 21.sp),
    bodyMedium = TextStyle(fontSize = 14.sp, lineHeight = 20.sp),
    bodySmall = TextStyle(fontSize = 12.sp, lineHeight = 17.sp),
    labelMedium = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 12.sp),
)

private val AppShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(28.dp),
)

@Composable
fun MatDekhaTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, typography = AppTypography, shapes = AppShapes, content = content)
}
