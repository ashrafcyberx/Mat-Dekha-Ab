import React from 'react';
import { ExternalLink, RotateCw } from 'lucide-react';
import { openInChrome, playerWebUrl } from '../native';

/** APK only: the video plays in Chrome, so this banner + button replaces the embedded player. */
export const NativePlayerBanner: React.FC<{ courseId: string; lessonId: string }> = ({ courseId, lessonId }) => {
  const open = () => { void openInChrome(playerWebUrl(courseId, lessonId)); };
  return (
    <div className="relative w-full aspect-video overflow-hidden bg-black lg:rounded-2xl">
      <img src="/player-banner.jpg" alt="Watch on Official Player" className="absolute inset-0 w-full h-full object-cover" />
      <button
        onClick={open}
        className="tb-press absolute left-[12%] bottom-[4%] h-[11%] min-h-9 w-[62%] rounded-full bg-[#FFD60A] text-[#111] font-heading font-bold text-[13px] sm:text-[15px] flex items-center justify-center gap-2 shadow-lg cursor-pointer"
      >
        <ExternalLink className="w-4 h-4" strokeWidth={2.4} /> Watch On Official Player
      </button>
      <button
        onClick={open}
        aria-label="Open again"
        className="tb-press absolute right-[5%] bottom-[4%] w-[9%] aspect-square rounded-full bg-black/45 text-white flex items-center justify-center cursor-pointer"
      >
        <RotateCw className="w-[55%] h-[55%]" />
      </button>
    </div>
  );
};
