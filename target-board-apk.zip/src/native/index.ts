import { Capacitor, registerPlugin } from '@capacitor/core';

/** Website that hosts the real video player (the APK only shows notes + lists, videos open in Chrome). */
export const WEB_ORIGIN: string =
  ((import.meta as any).env?.VITE_WEB_URL as string | undefined)?.replace(/\/+$/, '') || 'https://erx-tb.vercel.app';

/** true only inside the installed APK */
export const isNative = (): boolean => {
  try { return Capacitor.isNativePlatform(); } catch { return false; }
};

interface ChromeLauncherPlugin {
  open(options: { url: string }): Promise<void>;
}
const ChromeLauncher = registerPlugin<ChromeLauncherPlugin>('ChromeLauncher');

/** Opens a link in the Chrome app (falls back to the default browser). On the web it opens a new tab. */
export async function openInChrome(url: string): Promise<void> {
  if (isNative()) {
    try {
      await ChromeLauncher.open({ url });
      return;
    } catch {
      /* fall through to window.open */
    }
  }
  window.open(url, '_blank', 'noopener,noreferrer');
}

/** Web player link for a lesson, e.g. https://erx-tb.vercel.app/player/<courseId>/<lessonId> */
export const playerWebUrl = (courseId: string, lessonId: string): string =>
  `${WEB_ORIGIN}/player/${encodeURIComponent(courseId)}/${encodeURIComponent(lessonId)}`;
