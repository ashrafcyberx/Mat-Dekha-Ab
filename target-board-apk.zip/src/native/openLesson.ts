import type { NavigateFunction } from 'react-router-dom';
import { isNative, openInChrome, playerWebUrl } from './index';

/**
 * Every "play this class" tap goes through here.
 * - Website: normal in-page navigation to the player.
 * - APK: shows the player page (banner) AND immediately launches the video in Chrome.
 */
export function openLesson(navigate: NavigateFunction, courseId: string, lessonId: string, opts?: { replace?: boolean }) {
  navigate(`/player/${courseId}/${lessonId}`, { replace: !!opts?.replace });
  if (isNative()) void openInChrome(playerWebUrl(courseId, lessonId));
}
