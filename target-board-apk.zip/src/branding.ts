export const OFFICIAL_LOGO = 'https://files.catbox.moe/4tbsk3.jpg';
export const VIDEO_THUMBNAIL = 'https://i.ibb.co/GQjPSB7k/uploaded-image.jpg';
export const BRAND_NAME = 'Ashraf CyberX';

export const SOCIAL_LINKS = {
  youtube: 'https://youtube.com/@ashraf_cyberx?si=Uw3PAMKLQG_O84zV',
  instagram: 'https://www.instagram.com/ashraf_cyberx?stkn=aGEyNG5lZm5namFx',
  telegram: 'https://t.me/Ashraf_CyberX',
  whatsappChannel: 'https://whatsapp.com/channel/0029VbDr1TL8kyyHB4MATv3Q'
};

/** Banner shown for any batch that has no (working) thumbnail */
export const DEFAULT_THUMBNAIL = '/default-batch.jpg';
