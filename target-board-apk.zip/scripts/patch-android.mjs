// Run after `npx cap add android`: adds the Chrome launcher plugin, icons, splash, signing and theme.
import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const app = path.join(root, 'android', 'app');
const patch = path.join(root, 'android-patch');
const pkgDir = path.join(app, 'src/main/java/com/targetboard/mod');

const copy = (from, to) => { fs.mkdirSync(path.dirname(to), { recursive: true }); fs.copyFileSync(from, to); };

// 1. Java: MainActivity + ChromeLauncher plugin
fs.mkdirSync(pkgDir, { recursive: true });
for (const f of ['MainActivity.java', 'ChromeLauncherPlugin.java']) copy(path.join(patch, 'java', f), path.join(pkgDir, f));

// 2. Icons (overwrite template ones) + background colour
const res = path.join(app, 'src/main/res');
for (const d of fs.readdirSync(path.join(patch, 'res'))) {
  const src = path.join(patch, 'res', d);
  if (fs.statSync(src).isDirectory()) for (const f of fs.readdirSync(src)) copy(path.join(src, f), path.join(res, d, f));
}

// 3. Splash: replace every template splash.png with ours
const walk = (dir) => fs.readdirSync(dir, { withFileTypes: true }).flatMap((e) => e.isDirectory() ? walk(path.join(dir, e.name)) : [path.join(dir, e.name)]);
for (const f of walk(res)) if (path.basename(f) === 'splash.png') copy(path.join(patch, 'res/splash.png'), f);

// 4. Status / navigation bar colours (matches the yellow UI)
const stylesFile = path.join(res, 'values/styles.xml');
let styles = fs.readFileSync(stylesFile, 'utf8');
styles = styles.replace(/(<style name="AppTheme\.NoActionBar"[^>]*>)/, '$1\n        <item name="android:statusBarColor">#FFEF7A</item>\n        <item name="android:windowLightStatusBar">true</item>\n        <item name="android:navigationBarColor">#FFFFFF</item>\n        <item name="android:windowLightNavigationBar">true</item>');
fs.writeFileSync(stylesFile, styles);

// 5. Release signing with the bundled keystore + version
const gradleFile = path.join(app, 'build.gradle');
let g = fs.readFileSync(gradleFile, 'utf8');
copy(path.join(patch, 'target-board.keystore'), path.join(app, 'target-board.keystore'));
const version = process.env.APP_VERSION || '1.0';
const code = process.env.APP_VERSION_CODE || '1';
g = g.replace(/versionCode\s+\d+/, `versionCode ${code}`).replace(/versionName\s+"[^"]*"/, `versionName "${version}"`);
g = g.replace('buildTypes {', `signingConfigs {
        release {
            storeFile file('target-board.keystore')
            storePassword 'targetboard123'
            keyAlias 'targetboard'
            keyPassword 'targetboard123'
        }
    }
    buildTypes {`);
g = g.replace(/buildTypes \{\s*release \{/, (m) => m + '\n            signingConfig signingConfigs.release');
fs.writeFileSync(gradleFile, g);
console.log('Android project patched.');
