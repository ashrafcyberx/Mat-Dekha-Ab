# Target Board MOD

Free board exam batches, video lectures and chapter notes.

## APK (Android) — how it works

- The APK shows courses, chapters and notes (PDF) inside the app.
- Tapping a **video** opens it directly in **Chrome** on your website
  (`https://erx-tb.vercel.app/player/<courseId>/<lessonId>`). The in-app page shows the
  "Watch On Official Player" banner with a button to open it again.
- Website URL is set in `src/native/index.ts` (or env `VITE_WEB_URL`).

### Build the APK on GitHub
1. Create a GitHub repo and upload everything from this folder (including the hidden `.github` folder).
2. Open **Actions → Build APK → Run workflow** (it also runs on every push).
3. When it finishes, download **TargetBoardMOD-apk** from the run's *Artifacts* → unzip → install `TargetBoardMOD.apk`.

### Important
- Deploy this same code to Vercel too (`vercel.json` now sends CORS headers for `/tbapi`). The APK reads its data through that deployment, and Chrome plays videos from it.
- The bundled `android-patch/target-board.keystore` keeps your APK signature the same on every build so updates install over the old app. Replace it with your own keystore before any Play Store release.

## Web

```bash
npm install
npm run dev
npm run build
```
Earlier API / proxy notes: see `api/tbapi.js`, `proxy/tbproxy.cjs`, `cloudflare/worker.js`.
