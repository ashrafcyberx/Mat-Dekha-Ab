package com.targetboard.mod;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;

import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

/** Opens a link directly in the Chrome app (falls back to the default browser if Chrome is missing). */
@CapacitorPlugin(name = "ChromeLauncher")
public class ChromeLauncherPlugin extends Plugin {

    @PluginMethod
    public void open(PluginCall call) {
        String url = call.getString("url");
        if (url == null || url.isEmpty()) {
            call.reject("url is required");
            return;
        }
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            intent.setPackage("com.android.chrome");
            getActivity().startActivity(intent);
            call.resolve();
        } catch (ActivityNotFoundException chromeMissing) {
            try {
                intent.setPackage(null);
                getActivity().startActivity(intent);
                call.resolve();
            } catch (Exception e) {
                call.reject("No browser found");
            }
        }
    }
}
