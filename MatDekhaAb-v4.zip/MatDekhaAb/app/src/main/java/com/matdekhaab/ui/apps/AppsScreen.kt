package com.matdekhaab.ui.apps

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.matdekhaab.ui.components.*
import com.matdekhaab.ui.formatDuration
import com.matdekhaab.ui.formatMinutes
import com.matdekhaab.ui.theme.Accent
import com.matdekhaab.ui.theme.OnAccent
import com.matdekhaab.ui.theme.Surface3

@Composable
fun AppsScreen(vm: AppsViewModel) {
    val appItems by vm.items.collectAsStateWithLifecycle()
    val query by vm.query.collectAsStateWithLifecycle()
    val loading by vm.loading.collectAsStateWithLifecycle()
    val selectedCount by vm.selectedCount.collectAsStateWithLifecycle()
    val serviceOn by vm.serviceOn.collectAsStateWithLifecycle()
    val accessGranted by vm.accessGranted.collectAsStateWithLifecycle()
    var editing by remember { mutableStateOf<AppItem?>(null) }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item(key = "header") {
            ScreenHeader("App Blocker", "$selectedCount app(s) selected")
        }
        if (!serviceOn) {
            item(key = "service") { AccessibilityCard() }
        }
        if (!accessGranted) {
            item(key = "usage") {
                StatusBanner(
                    title = "Usage Access needed",
                    body = "Limits are measured from Android's usage data. Allow Usage Access from the Home tab.",
                )
            }
        }
        item(key = "how") {
            Text(
                "Turn an app on, then pick a daily limit. When the limit is reached the app is closed until midnight. " +
                    "An app with no limit is only tracked, not blocked.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        item(key = "search") {
            OutlinedTextField(
                value = query,
                onValueChange = vm::setQuery,
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Search apps") },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
            )
        }
        if (loading) {
            item(key = "loading") { EmptyHint("Loading apps…") }
        } else if (appItems.isEmpty()) {
            item(key = "empty") { EmptyHint("No apps found.") }
        } else {
            items(appItems, key = { it.packageName }) { app ->
                AppCard(Modifier.clickable(enabled = app.selected) { editing = app }) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        AppIcon(app.packageName)
                        Column(Modifier.weight(1f)) {
                            Text(app.label, style = MaterialTheme.typography.titleMedium, maxLines = 1)
                            Text(
                                subtitle(app),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                            val limit = app.limitMin
                            if (app.selected && limit != null) {
                                LinearProgressIndicator(
                                    progress = { (app.usedMs.toFloat() / (limit * 60_000f)).coerceIn(0f, 1f) },
                                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                                    color = Accent,
                                    trackColor = Surface3,
                                )
                            }
                        }
                        Switch(
                            checked = app.selected,
                            onCheckedChange = { on ->
                                vm.toggle(app.packageName, on)
                                if (on) editing = app.copy(selected = true)
                            },
                            colors = SwitchDefaults.colors(checkedTrackColor = Accent, checkedThumbColor = OnAccent),
                        )
                    }
                }
            }
        }
    }

    editing?.let { app ->
        LimitPickerDialog(
            title = "${app.label} · daily limit",
            currentMin = app.limitMin,
            onDismiss = { editing = null },
            onSave = { min ->
                vm.setLimit(app.packageName, min)
                editing = null
            },
        )
    }
}

private fun subtitle(app: AppItem): String = when {
    !app.selected -> "Today: ${formatDuration(app.usedMs)}"
    app.limitMin != null -> "Limit ${formatMinutes(app.limitMin)} · used ${formatDuration(app.usedMs)} · tap to edit"
    else -> "No limit · used ${formatDuration(app.usedMs)} · tap to set"
}
