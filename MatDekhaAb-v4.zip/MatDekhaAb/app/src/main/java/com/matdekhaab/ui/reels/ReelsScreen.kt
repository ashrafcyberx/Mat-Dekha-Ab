package com.matdekhaab.ui.reels

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.matdekhaab.domain.ReelStats
import com.matdekhaab.ui.components.*
import com.matdekhaab.ui.formatMinutes
import com.matdekhaab.ui.theme.Accent
import com.matdekhaab.ui.theme.OnAccent
import com.matdekhaab.ui.theme.Surface3

private enum class Target { Instagram, YouTube }

@Composable
fun ReelsScreen(vm: ReelsViewModel, onOpenAppBlocker: () -> Unit) {
    val settings by vm.settings.collectAsStateWithLifecycle()
    val stats by vm.stats.collectAsStateWithLifecycle()
    val serviceOn by vm.serviceOn.collectAsStateWithLifecycle()
    var dialog by remember { mutableStateOf<Target?>(null) }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item { ScreenHeader("Reels & Shorts", "Count, cap and block short-form video") }

        if (!serviceOn) {
            item { AccessibilityCard() }
        }

        item {
            StatusBanner(
                title = "Experimental detection",
                body = "Android has no official Reels-only signal. Detection reads Instagram/YouTube screen " +
                    "structure, is not guaranteed, and can stop working after their updates. If it misbehaves, " +
                    "use full-app blocking in the Apps tab. Counts and time are estimates.",
            )
        }

        item { SectionLabel("Reel counter") }
        item { CounterCard(stats) }

        item { SectionLabel("Reel blocker") }
        item {
            Text(
                "Switch on to enforce. With no limit, Reels/Shorts are blocked completely. With a limit, they are " +
                    "allowed until the estimated time is used up.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        item {
            ShortFormCard(
                title = "Instagram Reels",
                description = "Closes Instagram when you open Reels, keeping the rest of the app available.",
                enabled = settings.instagramReelsBlock,
                limitMin = settings.instagramReelsLimitMin.takeIf { it > 0 },
                onToggle = vm::setInstagramBlock,
                onEditLimit = { dialog = Target.Instagram },
                fallbackText = "Block all of Instagram instead",
                onFallback = onOpenAppBlocker,
            )
        }
        item {
            ShortFormCard(
                title = "YouTube Shorts",
                description = "Closes YouTube when you open Shorts, keeping regular videos available.",
                enabled = settings.youtubeShortsBlock,
                limitMin = settings.youtubeShortsLimitMin.takeIf { it > 0 },
                onToggle = vm::setYoutubeBlock,
                onEditLimit = { dialog = Target.YouTube },
                fallbackText = "Block all of YouTube instead",
                onFallback = onOpenAppBlocker,
            )
        }
    }

    dialog?.let { which ->
        val isIg = which == Target.Instagram
        LimitPickerDialog(
            title = if (isIg) "Instagram Reels · daily limit" else "YouTube Shorts · daily limit",
            currentMin = (if (isIg) settings.instagramReelsLimitMin else settings.youtubeShortsLimitMin).takeIf { it > 0 },
            onDismiss = { dialog = null },
            onSave = { min ->
                if (isIg) vm.setInstagramLimit(min) else vm.setYoutubeLimit(min)
                dialog = null
            },
        )
    }
}

@Composable
private fun CounterCard(stats: ReelStats?) {
    AppCard {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
            Text("Today", style = MaterialTheme.typography.titleMedium)
            Pill(if (stats == null) "Service off" else "Estimate")
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            CountTile("Instagram Reels", stats?.instagramReels?.toString() ?: "—", Modifier.weight(1f))
            CountTile("YouTube Shorts", stats?.youtubeShorts?.toString() ?: "—", Modifier.weight(1f))
        }
        Text(
            if (stats == null) "Turn on the blocking service to start counting."
            else "Estimated from detected swipes on screen. Not an exact measurement.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun CountTile(label: String, value: String, modifier: Modifier) {
    Column(modifier, verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(value, style = MaterialTheme.typography.headlineMedium, color = Accent)
        Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun ShortFormCard(
    title: String,
    description: String,
    enabled: Boolean,
    limitMin: Int?,
    onToggle: (Boolean) -> Unit,
    onEditLimit: () -> Unit,
    fallbackText: String,
    onFallback: () -> Unit,
) {
    AppCard {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(title, style = MaterialTheme.typography.titleMedium)
                Text(description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Switch(
                checked = enabled,
                onCheckedChange = onToggle,
                colors = SwitchDefaults.colors(checkedTrackColor = Accent, checkedThumbColor = OnAccent),
            )
        }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Column {
                Text("Daily limit (estimated)", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(limitMin?.let { formatMinutes(it) } ?: "No limit · block fully", style = MaterialTheme.typography.titleMedium)
            }
            Button(
                onClick = onEditLimit,
                colors = ButtonDefaults.buttonColors(containerColor = Surface3, contentColor = MaterialTheme.colorScheme.onSurface),
            ) { Text("Change") }
        }
        TextButton(onClick = onFallback) { Text("$fallbackText →", color = Accent) }
    }
}
