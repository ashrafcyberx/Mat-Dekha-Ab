package com.matdekhaab.service

import android.accessibilityservice.AccessibilityService
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.inputmethod.InputMethodManager
import androidx.core.content.ContextCompat
import com.matdekhaab.MatDekhaApp
import com.matdekhaab.core.AppContainer
import com.matdekhaab.domain.LimitEngine
import com.matdekhaab.domain.RestrictionSettings
import com.matdekhaab.domain.ShortForm
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

/**
 * Enforcement engine. Uses AccessibilityService ONLY to (1) learn which app is in the foreground and
 * (2) on Instagram/YouTube, check view ids for Reels/Shorts. When a limit is reached it sends the
 * user to the Home screen and shows [BlockedActivity]. It cannot (and does not try to) prevent
 * uninstalling, force-stopping or disabling itself: the user can always switch it off in Settings.
 */
class BlockerService : AccessibilityService() {

    companion object {
        private val _connected = MutableStateFlow(false)
        val connected: StateFlow<Boolean> = _connected
        private const val SYSTEM_UI = "com.android.systemui"
        private const val DETECT_MIN_GAP_MS = 250L
        private const val COUNT_DEBOUNCE_MS = 800L
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val ioScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private lateinit var container: AppContainer

    private var settings = RestrictionSettings()
    private var imePackages: Set<String> = emptySet()
    private var currentPkg: String? = null
    private var limitJob: Job? = null
    private var shortFormJob: Job? = null
    private var activeKind: ShortForm? = null
    private var activeSince = 0L
    private var lastCountAt = 0L
    private var lastDetectAt = 0L
    private var receiverRegistered = false

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                Intent.ACTION_SCREEN_OFF -> {
                    cancelMonitoring()
                    currentPkg = null
                }
                Intent.ACTION_USER_PRESENT -> scope.launch {
                    delay(600)
                    currentPkg = null
                    rootInActiveWindow?.packageName?.toString()?.let { onWindowChanged(it) }
                }
            }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        container = (application as MatDekhaApp).container
        imePackages = runCatching {
            getSystemService(InputMethodManager::class.java).enabledInputMethodList.map { it.packageName }.toSet()
        }.getOrDefault(emptySet())

        if (!receiverRegistered) {
            val filter = IntentFilter().apply {
                addAction(Intent.ACTION_SCREEN_OFF)
                addAction(Intent.ACTION_USER_PRESENT)
            }
            ContextCompat.registerReceiver(this, screenReceiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
            receiverRegistered = true
        }

        scope.launch {
            container.settings.settings.collect { s ->
                settings = s
                currentPkg?.let { evaluateApp(it) }
                activeKind?.let { enforceShortForm(it) }
            }
        }
        _connected.value = true
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val e = event ?: return
        val pkg = e.packageName?.toString() ?: return
        when (e.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> onWindowChanged(pkg)
            AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED,
            AccessibilityEvent.TYPE_VIEW_SCROLLED ->
                if (pkg == currentPkg && ShortFormDetector.isShortFormApp(pkg)) {
                    onShortFormSignal(pkg, e.eventType == AccessibilityEvent.TYPE_VIEW_SCROLLED)
                }
        }
    }

    override fun onInterrupt() { /* nothing to interrupt */ }

    override fun onUnbind(intent: Intent?): Boolean {
        _connected.value = false
        cancelMonitoring()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        _connected.value = false
        cancelMonitoring()
        if (receiverRegistered) {
            runCatching { unregisterReceiver(screenReceiver) }
            receiverRegistered = false
        }
        scope.cancel()
        super.onDestroy()
    }

    // ---------------------------------------------------------------- app limits

    private fun onWindowChanged(pkg: String) {
        if (pkg == packageName || pkg == SYSTEM_UI || pkg in imePackages) return
        if (pkg == currentPkg) return
        currentPkg = pkg
        limitJob?.cancel()
        exitShortForm()
        evaluateApp(pkg)
    }

    private fun evaluateApp(pkg: String) {
        limitJob?.cancel()
        limitJob = scope.launch {
            val s = container.settings.settings.first()
            val tracked = container.trackedApps.trackedPackages.first()
            val limitMin = s.appLimitsMin[pkg]
            if (pkg !in tracked || limitMin == null) return@launch
            // If Usage Access was revoked this throws; then we cannot enforce, so we do nothing.
            val used = runCatching { container.usageRepository.usedTodayMs(pkg) }.getOrNull() ?: return@launch
            val remaining = LimitEngine.remainingMs(limitMin, used)
            if (remaining > 0L) delay(remaining)
            if (currentPkg == pkg) blockApp(pkg)
        }
    }

    private fun blockApp(pkg: String) {
        val label = labelOf(pkg)
        currentPkg = null
        performGlobalAction(GLOBAL_ACTION_HOME)
        showBlocked("$label is blocked", "Your daily limit for $label has been reached. It resets at midnight.")
    }

    // ---------------------------------------------------------------- Reels / Shorts (experimental)

    private fun onShortFormSignal(pkg: String, scrolled: Boolean) {
        val now = SystemClock.elapsedRealtime()
        if (now - lastDetectAt < DETECT_MIN_GAP_MS) return
        lastDetectAt = now
        val kind = ShortFormDetector.detect(rootInActiveWindow, pkg)
        val prev = activeKind
        when {
            kind != null && prev == null -> enterShortForm(kind, now)
            kind != null && prev == kind ->
                if (scrolled && now - lastCountAt > COUNT_DEBOUNCE_MS) {
                    lastCountAt = now
                    ioScope.launch { container.reelStatsStore.addReel(kind) }
                }
            kind == null && prev != null -> exitShortForm()
        }
    }

    private fun enterShortForm(kind: ShortForm, now: Long) {
        activeKind = kind
        activeSince = now
        lastCountAt = now
        ioScope.launch { container.reelStatsStore.addReel(kind) }
        enforceShortForm(kind)
    }

    private fun exitShortForm() {
        val kind = activeKind ?: return
        val elapsed = SystemClock.elapsedRealtime() - activeSince
        activeKind = null
        shortFormJob?.cancel()
        ioScope.launch { container.reelStatsStore.addTime(kind, elapsed) }
    }

    /**
     * Blocker toggle ON + no limit  => blocked immediately.
     * Blocker toggle ON + limit set => allowed until the ESTIMATED time reaches the limit.
     */
    private fun enforceShortForm(kind: ShortForm) {
        shortFormJob?.cancel()
        val (block, limitMin) = when (kind) {
            ShortForm.InstagramReels -> settings.instagramReelsBlock to settings.instagramReelsLimitMin
            ShortForm.YouTubeShorts -> settings.youtubeShortsBlock to settings.youtubeShortsLimitMin
        }
        if (!block) return
        shortFormJob = scope.launch {
            val stored = container.reelStatsStore.usedMs(kind)
            val session = SystemClock.elapsedRealtime() - activeSince
            val remaining = if (limitMin <= 0) 0L else LimitEngine.remainingMs(limitMin, stored + session)
            if (remaining > 0L) delay(remaining)
            if (activeKind == kind) blockShortForm(kind, limitMin)
        }
    }

    private fun blockShortForm(kind: ShortForm, limitMin: Int) {
        exitShortForm()
        currentPkg = null
        performGlobalAction(GLOBAL_ACTION_HOME)
        val name = if (kind == ShortForm.InstagramReels) "Instagram Reels" else "YouTube Shorts"
        val message = if (limitMin <= 0) "You turned on the $name blocker."
        else "Your estimated daily limit of $limitMin min for $name has been reached."
        showBlocked("$name blocked", message)
    }

    // ---------------------------------------------------------------- helpers

    private fun cancelMonitoring() {
        limitJob?.cancel()
        exitShortForm()
    }

    private fun labelOf(pkg: String): String = runCatching {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    }.getOrDefault(pkg)

    private fun showBlocked(title: String, message: String) {
        // Best effort: HOME was already performed, so the user is safe even if this launch is refused.
        runCatching {
            startActivity(
                Intent(this, BlockedActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    .putExtra(BlockedActivity.EXTRA_TITLE, title)
                    .putExtra(BlockedActivity.EXTRA_MESSAGE, message)
            )
        }
    }
}
