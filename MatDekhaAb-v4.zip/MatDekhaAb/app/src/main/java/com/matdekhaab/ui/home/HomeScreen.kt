package com.matdekhaab.ui.home

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.matdekhaab.domain.DailyTotal
import com.matdekhaab.ui.components.*
import com.matdekhaab.ui.formatDuration
import com.matdekhaab.ui.theme.Accent
import com.matdekhaab.ui.theme.OnAccent
import com.matdekhaab.ui.theme.Surface3
import com.matdekhaab.ui.theme.TextPrimary
import java.time.format.TextStyle
import java.util.Locale

@Composable
fun HomeScreen(vm: HomeViewModel, onOpenAppBlocker: () -> Unit) {
    val context = LocalContext.current
    val granted by vm.accessGranted.collectAsStateWithLifecycle()
    val total by vm.totalMs.collectAsStateWithLifecycle()
    val top by vm.topApps.collectAsStateWithLifecycle()
    val weekly by vm.weekly.collectAsStateWithLifecycle()
    val trackedCount by vm.trackedCount.collectAsStateWithLifecycle()
    val serviceOn by vm.serviceOn.collectAsStateWithLifecycle()

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item { BrandHeader("Mat Dekha Ab", "Control your scroll") }

        if (!serviceOn) {
            item { AccessibilityCard() }
        }

        if (!granted) {
            item {
                StatusBanner(
                    title = "Usage Access needed",
                    body = "To show your screen time, Android requires you to allow Usage Access for this app. " +
                        "It is only read on this device and is never uploaded.",
                    extra = {
                        Button(
                            onClick = { launchFirstResolvable(context, vm.usageSettingsIntents()) },
                            colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = OnAccent),
                        ) { Text("Grant Usage Access") }
                    },
                )
            }
        }

        item {
            AppCard {
                SectionLabel("Today's screen time")
                Text(formatDuration(total), fontSize = 44.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                Text(
                    "Measured foreground time across your launchable apps.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                weekly?.let { WeeklyBars(it.dailyTotals) }
            }
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatTile("Daily average (7 days)", formatDuration(weekly?.dailyAverageMs ?: 0L), Modifier.weight(1f))
                StatTile("Apps selected", trackedCount.toString(), Modifier.weight(1f))
            }
        }

        item { SectionLabel("Most used today") }

        if (top.isEmpty()) {
            item { EmptyHint(if (granted) "No usage recorded yet today." else "Grant Usage Access to see your usage.") }
        } else {
            items(top, key = { it.packageName }) { row ->
                AppCard {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        AppIcon(row.packageName)
                        Column(Modifier.weight(1f)) {
                            Text(row.label, style = MaterialTheme.typography.titleMedium, maxLines = 1)
                            Text(
                                if (row.launchCount == 1) "1 launch" else "${row.launchCount} launches",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                        Text(formatDuration(row.foregroundMs), style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurface)
                    }
                }
            }
            item {
                Button(
                    onClick = onOpenAppBlocker,
                    colors = ButtonDefaults.buttonColors(containerColor = Surface3, contentColor = MaterialTheme.colorScheme.onSurface),
                    modifier = Modifier.fillMaxWidth(),
                ) { Text("Set limits in App Blocker") }
            }
        }
    }
}

@Composable
private fun WeeklyBars(days: List<DailyTotal>) {
    val max = (days.maxOfOrNull { it.totalMs } ?: 0L).coerceAtLeast(1L)
    Row(
        Modifier.fillMaxWidth().height(110.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.Bottom,
    ) {
        days.forEachIndexed { i, d ->
            val isToday = i == days.lastIndex
            Column(
                Modifier.weight(1f).fillMaxHeight(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Bottom,
            ) {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height((78f * d.totalMs / max).coerceAtLeast(3f).dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (isToday) Accent else Accent.copy(alpha = 0.30f))
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    d.date.dayOfWeek.getDisplayName(TextStyle.SHORT, Locale.getDefault()),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                )
            }
        }
    }
}

private fun launchFirstResolvable(context: Context, intents: List<Intent>) {
    for (i in intents) {
        try { context.startActivity(i); return } catch (ignored: Exception) { /* try next */ }
    }
}
