package com.matdekhaab.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.viewmodel.compose.viewModel
import com.matdekhaab.MatDekhaApp
import com.matdekhaab.ui.about.AboutScreen
import com.matdekhaab.ui.apps.AppsScreen
import com.matdekhaab.ui.home.HomeScreen
import com.matdekhaab.ui.home.HomeViewModel
import com.matdekhaab.ui.reels.ReelsScreen
import com.matdekhaab.ui.theme.Bg
import com.matdekhaab.ui.theme.Accent
import com.matdekhaab.ui.theme.Surface1
import com.matdekhaab.ui.theme.TextMuted

private enum class Tab(val label: String, val icon: ImageVector) {
    Home("Home", Icons.Filled.Home),
    Reels("Reels", Icons.Filled.PlayArrow),
    Apps("Apps", Icons.AutoMirrored.Filled.List),
    About("About", Icons.Filled.Info),
}

@Composable
fun AppRoot() {
    val container = (LocalContext.current.applicationContext as MatDekhaApp).container
    val factory = remember { VmFactory(container) }
    val home: HomeViewModel = viewModel(factory = factory)
    var tab by rememberSaveable { mutableStateOf(Tab.Home) }

    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { home.refresh() }

    Scaffold(
        containerColor = Bg,
        bottomBar = {
            NavigationBar(containerColor = Surface1, tonalElevation = 0.dp) {
                Tab.entries.forEach { t ->
                    NavigationBarItem(
                        selected = tab == t,
                        onClick = { tab = t },
                        icon = { Icon(t.icon, contentDescription = t.label) },
                        label = { Text(t.label) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Accent,
                            selectedTextColor = Accent,
                            indicatorColor = Accent.copy(alpha = 0.16f),
                            unselectedIconColor = TextMuted,
                            unselectedTextColor = TextMuted,
                        ),
                    )
                }
            }
        },
    ) { padding ->
        Box(Modifier.padding(padding)) {
            when (tab) {
                Tab.Home -> HomeScreen(home, onOpenAppBlocker = { tab = Tab.Apps })
                Tab.Reels -> ReelsScreen(viewModel(factory = factory), onOpenAppBlocker = { tab = Tab.Apps })
                Tab.Apps -> AppsScreen(viewModel(factory = factory))
                Tab.About -> AboutScreen(viewModel(factory = factory))
            }
        }
    }
}
