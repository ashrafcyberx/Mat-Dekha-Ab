# Mat Dekha Ab v0.4.0 (v5) - what changed

## Blocking (fast + reliable)
- Reels/Shorts detection now runs off the main thread with a trailing re-check (last event is never dropped).
- Needs 2 misses before deciding you left Reels (no more false exit / double count).
- Catches Instagram/YouTube even if the window-change event was missed.
- Reel counter writes no longer restart limit timers (settings flows are de-duplicated) - this was a big slowdown.
- App that already hit its limit is blocked INSTANTLY when reopened (no UsageStats query).
- Blocked screen now updates its text on every block (singleTask stale-intent bug fixed).
- Accessibility notificationTimeout 300 -> 100 ms.
- If Reels still isn't detected after an Instagram/YouTube update: edit the id lists in service/ShortFormDetector.kt.

## UI
- New dark brand theme from the logo (black + signal red + green), glass cards, gradient buttons.
- Home: progress ring vs 7-day average, weekly bars, ranked top apps, Blocker ON/OFF chip.
- Reels / Apps / About / Blocked screens redesigned; icon cache for smooth scrolling.
- Developer portrait (71530.png) added as res/drawable-nodpi/dev_avatar.jpg, used on About.
