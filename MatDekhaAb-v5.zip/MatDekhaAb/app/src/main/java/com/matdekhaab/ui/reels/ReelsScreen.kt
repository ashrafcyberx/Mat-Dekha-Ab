package com.matdekhaab.ui.reels

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.matdekhaab.domain.ReelStats
import com.matdekhaab.ui.components.*
import com.matdekhaab.ui.formatMinutes
import com.matdekhaab.ui.theme.Accent
import com.matdekhaab.ui.theme.Success
import com.matdekhaab.ui.theme.TextMuted

private enum class Target { Instagram, YouTube }

private val InstagramBrush = Brush.linearGradient(listOf(Color(0xFFF58529), Color(0xFFDD2A7B), Color(0xFF8134AF)))
private val YouTubeBrush = Brush.linearGradient(listOf(Color(0xFFFF3B3B), Color(0xFFB80000)))

@Composable
fun ReelsScreen(vm: ReelsViewModel, onOpenAppBlocker: () -> Unit) {
    val settings by vm.settings.collectAsStateWithLifecycle()
    val stats by vm.stats.collectAsStateWithLifecycle()
    val serviceOn by vm.serviceOn.collectAsStateWithLifecycle()
    var dialog by remember { mutableStateOf<Target?>(null) }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item(key = "header") { ScreenHeader("Reels & Shorts", "Count, cap and block short-form video") }

        if (!serviceOn) {
            item(key = "service") { AccessibilityCard() }
        }

        item(key = "counter-label") { SectionLabel("Reel counter") }
        item(key = "counter") { CounterCard(stats) }

        item(key = "blocker-label") { SectionLabel("Reel blocker") }
        item(key = "blocker-help") {
            Text(
                "Switch on to enforce. With no limit, Reels/Shorts are blocked completely. With a limit, they are " +
                    "allowed until the estimated time is used up.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        item(key = "instagram") {
            ShortFormCard(
                badge = "IG",
                badgeBrush = InstagramBrush,
                title = "Instagram Reels",
                description = "Closes Instagram when you open Reels, keeping the rest of the app available.",
                enabled = settings.instagramReelsBlock,
                limitMin = settings.instagramReelsLimitMin.takeIf { it > 0 },
                onToggle = vm::setInstagramBlock,
                onEditLimit = { dialog = Target.Instagram },
                fallbackText = "Block all of Instagram instead",
                onFallback = onOpenAppBlocker,
            )
        }
        item(key = "youtube") {
            ShortFormCard(
                badge = "YT",
                badgeBrush = YouTubeBrush,
                title = "YouTube Shorts",
                description = "Closes YouTube when you open Shorts, keeping regular videos available.",
                enabled = settings.youtubeShortsBlock,
                limitMin = settings.youtubeShortsLimitMin.takeIf { it > 0 },
                onToggle = vm::setYoutubeBlock,
                onEditLimit = { dialog = Target.YouTube },
                fallbackText = "Block all of YouTube instead",
                onFallback = onOpenAppBlocker,
            )
        }
        item(key = "experimental") {
            StatusBanner(
                title = "Experimental detection",
                body = "Android has no official Reels-only signal. Detection reads Instagram/YouTube screen " +
                    "structure, is not guaranteed, and can stop working after their updates. If it misbehaves, " +
                    "use full-app blocking in the Apps tab. Counts and time are estimates.",
            )
        }
    }

    dialog?.let { which ->
        val isIg = which == Target.Instagram
        LimitPickerDialog(
            title = if (isIg) "Instagram Reels · daily limit" else "YouTube Shorts · daily limit",
            currentMin = (if (isIg) settings.instagramReelsLimitMin else settings.youtubeShortsLimitMin).takeIf { it > 0 },
            onDismiss = { dialog = null },
            onSave = { min ->
                if (isIg) vm.setInstagramLimit(min) else vm.setYoutubeLimit(min)
                dialog = null
            },
        )
    }
}

@Composable
private fun CounterCard(stats: ReelStats?) {
    AppCard(highlight = true) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
            Text("Today", style = MaterialTheme.typography.titleMedium)
            Pill(if (stats == null) "Service off" else "Estimate", if (stats == null) TextMuted else Success)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            CountTile("Instagram Reels", stats?.instagramReels?.toString() ?: "—", Modifier.weight(1f))
            CountTile("YouTube Shorts", stats?.youtubeShorts?.toString() ?: "—", Modifier.weight(1f))
        }
        Text(
            if (stats == null) "Turn on the blocking service to start counting."
            else "Estimated from detected swipes on screen. Not an exact measurement.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun CountTile(label: String, value: String, modifier: Modifier) {
    Column(
        modifier
            .clip(RoundedCornerShape(14.dp))
            .background(Color(0x0DFFFFFF))
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(2.dp),
    ) {
        Text(value, fontSize = 34.sp, fontWeight = FontWeight.ExtraBold, color = Accent)
        Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun ShortFormCard(
    badge: String,
    badgeBrush: Brush,
    title: String,
    description: String,
    enabled: Boolean,
    limitMin: Int?,
    onToggle: (Boolean) -> Unit,
    onEditLimit: () -> Unit,
    fallbackText: String,
    onFallback: () -> Unit,
) {
    AppCard {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(
                Modifier.size(44.dp).clip(RoundedCornerShape(13.dp)).background(badgeBrush),
                contentAlignment = Alignment.Center,
            ) {
                Text(badge, color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(title, style = MaterialTheme.typography.titleMedium)
                    Pill(if (enabled) "ON" else "OFF", if (enabled) Success else TextMuted)
                }
                Text(description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Switch(checked = enabled, onCheckedChange = onToggle, colors = appSwitchColors())
        }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Column(Modifier.weight(1f)) {
                Text("Daily limit (estimated)", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(limitMin?.let { formatMinutes(it) } ?: "No limit · block fully", style = MaterialTheme.typography.titleMedium)
            }
            GhostButton("Change", onEditLimit)
        }
        TextButton(onClick = onFallback) { Text("$fallbackText →", color = Accent) }
    }
}
