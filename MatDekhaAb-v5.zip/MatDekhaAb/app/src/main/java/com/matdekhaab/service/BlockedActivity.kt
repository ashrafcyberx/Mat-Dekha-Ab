package com.matdekhaab.service

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.setContent
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.background
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.matdekhaab.MainActivity
import com.matdekhaab.ui.components.AppBackground
import com.matdekhaab.ui.components.GradientButton
import com.matdekhaab.ui.components.LogoMark
import com.matdekhaab.ui.theme.Accent
import com.matdekhaab.ui.theme.MatDekhaTheme
import com.matdekhaab.ui.theme.TextMuted

/** Shown when a limit triggers. Always offers: go Home, open the app, or switch blocking off. */
class BlockedActivity : ComponentActivity() {

    // Held as Compose state so a second block (singleTask re-delivery) updates the visible text.
    private var blockTitle by mutableStateOf("Blocked")
    private var blockMessage by mutableStateOf("")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        readExtras(intent)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() = goHome()
        })

        setContent {
            MatDekhaTheme {
                AppBackground {
                    BlockedScreen(
                        title = blockTitle,
                        message = blockMessage,
                        onHome = { goHome() },
                        onOpenApp = { openApp() },
                        onTurnOff = { openAccessibilitySettings() },
                    )
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        readExtras(intent)
    }

    private fun readExtras(i: Intent?) {
        blockTitle = i?.getStringExtra(EXTRA_TITLE) ?: "Blocked"
        blockMessage = i?.getStringExtra(EXTRA_MESSAGE) ?: ""
    }

    private fun goHome() {
        startActivity(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        finishAndRemoveTask()
    }

    private fun openApp() {
        startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        finishAndRemoveTask()
    }

    private fun openAccessibilitySettings() {
        runCatching {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        finishAndRemoveTask()
    }

    companion object {
        const val EXTRA_TITLE = "title"
        const val EXTRA_MESSAGE = "message"
    }
}

private val Nudges = listOf(
    "Mat dekha ab. Ye time tera hai, kuch bana, kuch seekh. 💪",
    "Scroll kam, kaam zyada. Tu isse bada hai! 🔥",
    "Phone rakh, duniya dekh. Real life zyada mast hai. 🌍",
    "Ek minute ruk. Kya sach mein isi ke liye aaya tha? 🤔",
)

@Composable
private fun BlockedScreen(
    title: String,
    message: String,
    onHome: () -> Unit,
    onOpenApp: () -> Unit,
    onTurnOff: () -> Unit,
) {
    val nudge = remember(title, message) { Nudges[(title + message).hashCode().mod(Nudges.size)] }
    val pulse = rememberInfiniteTransition(label = "pulse")
    val scale by pulse.animateFloat(
        initialValue = 1f,
        targetValue = 1.07f,
        animationSpec = infiniteRepeatable(tween(1400, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "scale",
    )

    Box(Modifier.fillMaxSize().systemBarsPadding().padding(24.dp), contentAlignment = Alignment.Center) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Box(
                Modifier
                    .size(168.dp)
                    .graphicsLayer { scaleX = scale; scaleY = scale }
                    .clip(CircleShape)
                    .background(Brush.radialGradient(listOf(Accent.copy(alpha = 0.35f), Color.Transparent))),
                contentAlignment = Alignment.Center,
            ) {
                LogoMark(112.dp)
            }
            Text(
                title,
                style = MaterialTheme.typography.headlineMedium,
                textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onBackground,
            )
            Text(
                message,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
            )
            Text(
                nudge,
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold,
                color = Accent,
                textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(6.dp))
            GradientButton("Go to Home screen", onHome, Modifier.fillMaxWidth())
            TextButton(onClick = onOpenApp) { Text("Open Mat Dekha Ab", color = Accent) }
            TextButton(onClick = onTurnOff) {
                Text("Turn off blocking (Accessibility settings)", color = TextMuted)
            }
        }
    }
}
