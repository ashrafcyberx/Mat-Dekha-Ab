package com.matdekhaab.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// Brand palette taken from the Mat Dekha Ab logo: deep black, signal red, and a green timer accent.
val Bg = Color(0xFF05070D)
val Surface1 = Color(0xFF0D111B)
val Surface2 = Color(0xFF141A28)
val Surface3 = Color(0xFF1E2538)
val Accent = Color(0xFFFF4D4F)
val AccentLight = Color(0xFFFF9A8B)
val AccentDeep = Color(0xFFD7263D)
val Ember = Color(0xFFFF8A3D)
val OnAccent = Color(0xFFFFFFFF)
val TextPrimary = Color(0xFFF2F5FA)
val TextMuted = Color(0xFF8E9AB0)
val Line = Color(0x1AFFFFFF)
val Success = Color(0xFF2EE59D)
val Warning = Color(0xFFFFB84D)
val Danger = Color(0xFFFF6B81)

val BrandGradient: Brush = Brush.linearGradient(listOf(AccentDeep, Accent, Ember))

private val Scheme = darkColorScheme(
    primary = Accent,
    onPrimary = OnAccent,
    primaryContainer = Color(0xFF3A1216),
    onPrimaryContainer = AccentLight,
    secondary = Ember,
    tertiary = Success,
    background = Bg,
    onBackground = TextPrimary,
    surface = Surface1,
    onSurface = TextPrimary,
    surfaceVariant = Surface2,
    onSurfaceVariant = TextMuted,
    surfaceContainer = Surface1,
    surfaceContainerHigh = Surface2,
    surfaceContainerHighest = Surface3,
    outline = Line,
    outlineVariant = Line,
    error = Danger,
)

private val AppTypography = Typography(
    headlineMedium = TextStyle(fontWeight = FontWeight.ExtraBold, fontSize = 26.sp, lineHeight = 32.sp),
    titleLarge = TextStyle(fontWeight = FontWeight.Bold, fontSize = 20.sp, lineHeight = 26.sp),
    titleMedium = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 15.sp, lineHeight = 21.sp),
    bodyMedium = TextStyle(fontSize = 14.sp, lineHeight = 20.sp),
    bodySmall = TextStyle(fontSize = 12.sp, lineHeight = 17.sp),
    labelMedium = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 12.sp),
)

private val AppShapes = Shapes(
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(24.dp),
)

@Composable
fun MatDekhaTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, typography = AppTypography, shapes = AppShapes, content = content)
}
