package com.matdekhaab.ui.home

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.matdekhaab.domain.DailyTotal
import com.matdekhaab.domain.UsageSummary
import com.matdekhaab.ui.components.*
import com.matdekhaab.ui.formatDuration
import com.matdekhaab.ui.theme.Accent
import com.matdekhaab.ui.theme.Ember
import com.matdekhaab.ui.theme.Success
import com.matdekhaab.ui.theme.Surface3
import com.matdekhaab.ui.theme.TextPrimary
import com.matdekhaab.ui.theme.Warning
import java.time.format.TextStyle
import java.util.Locale

@Composable
fun HomeScreen(vm: HomeViewModel, onOpenAppBlocker: () -> Unit) {
    val context = LocalContext.current
    val granted by vm.accessGranted.collectAsStateWithLifecycle()
    val total by vm.totalMs.collectAsStateWithLifecycle()
    val top by vm.topApps.collectAsStateWithLifecycle()
    val weekly by vm.weekly.collectAsStateWithLifecycle()
    val trackedCount by vm.trackedCount.collectAsStateWithLifecycle()
    val serviceOn by vm.serviceOn.collectAsStateWithLifecycle()

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item(key = "brand") { BrandHeader("Control your scroll", serviceOn) }

        if (!serviceOn) {
            item(key = "service") { AccessibilityCard() }
        }

        if (!granted) {
            item(key = "usage") {
                StatusBanner(
                    title = "Usage Access needed",
                    body = "To show your screen time, Android requires you to allow Usage Access for this app. " +
                        "It is only read on this device and is never uploaded.",
                    extra = {
                        GradientButton(
                            text = "Grant Usage Access",
                            onClick = { launchFirstResolvable(context, vm.usageSettingsIntents()) },
                            modifier = Modifier.fillMaxWidth(),
                        )
                    },
                )
            }
        }

        item(key = "hero") { HeroCard(total, weekly) }

        item(key = "stats") {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatTile(
                    label = "Daily average (7 days)",
                    value = formatDuration(weekly?.dailyAverageMs ?: 0L),
                    modifier = Modifier.weight(1f),
                    emoji = "📊",
                )
                StatTile(
                    label = "Apps selected",
                    value = trackedCount.toString(),
                    modifier = Modifier.weight(1f),
                    emoji = "🛡️",
                )
            }
        }

        item(key = "top-label") { SectionLabel("Most used today") }

        if (top.isEmpty()) {
            item(key = "empty") {
                EmptyHint(if (granted) "No usage recorded yet today." else "Grant Usage Access to see your usage.")
            }
        } else {
            val maxMs = top.maxOf { it.foregroundMs }.coerceAtLeast(1L)
            itemsIndexed(top, key = { _, row -> row.packageName }) { index, row ->
                AppCard {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text(
                            "${index + 1}",
                            color = if (index == 0) Accent else MaterialTheme.colorScheme.onSurfaceVariant,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 14.sp,
                            modifier = Modifier.width(14.dp),
                        )
                        AppIcon(row.packageName)
                        Column(Modifier.weight(1f)) {
                            Text(row.label, style = MaterialTheme.typography.titleMedium, maxLines = 1)
                            Text(
                                if (row.launchCount == 1) "1 launch" else "${row.launchCount} launches",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                        Text(
                            formatDuration(row.foregroundMs),
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface,
                        )
                    }
                    MiniBar(
                        progress = row.foregroundMs.toFloat() / maxMs,
                        color = if (index == 0) Accent else Ember.copy(alpha = 0.75f),
                    )
                }
            }
            item(key = "cta") {
                GradientButton(
                    text = "Set limits in App Blocker",
                    onClick = onOpenAppBlocker,
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        }
    }
}

@Composable
private fun HeroCard(totalMs: Long, weekly: UsageSummary?) {
    val avgMs = weekly?.dailyAverageMs ?: 0L
    val ratio = if (avgMs > 0L) totalMs.toFloat() / avgMs else 0f
    val ringColor = when {
        avgMs <= 0L -> Accent
        ratio < 0.75f -> Success
        ratio < 1f -> Warning
        else -> Accent
    }
    val message = when {
        avgMs <= 0L -> "Aaj ka hisaab shuru ho gaya 📱"
        ratio < 0.75f -> "Shabash! Aaj control mein ho 💪"
        ratio < 1f -> "Average ke kareeb ho, dhyaan rakho 👀"
        else -> "Average se zyada ho gaya. Mat dekha ab! 🚫"
    }

    AppCard(highlight = true) {
        Text(
            "TODAY'S SCREEN TIME",
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            letterSpacing = 1.2.sp,
        )
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            ProgressRing(
                progress = if (avgMs > 0L) ratio else 0f,
                color = ringColor,
                modifier = Modifier.size(128.dp),
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(formatDuration(totalMs), fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, color = TextPrimary)
                    Text("today", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(message, style = MaterialTheme.typography.titleMedium)
                Text(
                    if (avgMs > 0L) "7-day average: ${formatDuration(avgMs)}" else "Collecting your data…",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Text(
                    "Foreground time across your launchable apps.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        weekly?.let { WeeklyBars(it.dailyTotals) }
    }
}

@Composable
private fun WeeklyBars(days: List<DailyTotal>) {
    val max = (days.maxOfOrNull { it.totalMs } ?: 0L).coerceAtLeast(1L)
    Row(
        Modifier.fillMaxWidth().height(124.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.Bottom,
    ) {
        days.forEachIndexed { i, d ->
            val isToday = i == days.lastIndex
            Column(
                Modifier.weight(1f).fillMaxHeight(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Bottom,
            ) {
                if (isToday) {
                    Text(
                        formatDuration(d.totalMs),
                        style = MaterialTheme.typography.bodySmall,
                        color = Accent,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                    )
                    Spacer(Modifier.height(3.dp))
                }
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height((76f * d.totalMs / max).coerceAtLeast(4f).dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(
                            if (isToday) Brush.verticalGradient(listOf(Ember, Accent))
                            else Brush.verticalGradient(listOf(Surface3, Surface3))
                        )
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    d.date.dayOfWeek.getDisplayName(TextStyle.SHORT, Locale.getDefault()),
                    style = MaterialTheme.typography.bodySmall,
                    color = if (isToday) TextPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                )
            }
        }
    }
}

private fun launchFirstResolvable(context: Context, intents: List<Intent>) {
    for (i in intents) {
        try { context.startActivity(i); return } catch (ignored: Exception) { /* try next */ }
    }
}
