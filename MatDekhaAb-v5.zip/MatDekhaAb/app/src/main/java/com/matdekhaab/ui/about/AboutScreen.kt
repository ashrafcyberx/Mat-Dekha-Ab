package com.matdekhaab.ui.about

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.matdekhaab.R
import com.matdekhaab.core.FeatureAvailability
import com.matdekhaab.core.FeatureStatus
import com.matdekhaab.ui.components.*
import com.matdekhaab.ui.theme.Danger
import com.matdekhaab.ui.theme.Accent
import com.matdekhaab.ui.theme.AccentLight
import com.matdekhaab.ui.theme.Line
import com.matdekhaab.ui.theme.Success
import com.matdekhaab.ui.theme.Warning
import com.matdekhaab.ui.theme.Surface2
import com.matdekhaab.ui.theme.Surface3

@Composable
fun AboutScreen(vm: AboutViewModel) {
    val context = LocalContext.current
    var confirmClear by remember { mutableStateOf(false) }
    val version = remember {
        runCatching { context.packageManager.getPackageInfo(context.packageName, 0).versionName }.getOrNull() ?: ""
    }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item { ScreenHeader("Developer Info", "The person behind Mat Dekha Ab") }

        // Profile
        item {
            AppCard(highlight = true) {
                Column(
                    Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Pill(DeveloperInfo.TAG)
                    DevAvatar()
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(DeveloperInfo.NAME, style = MaterialTheme.typography.titleLarge)
                        Icon(Icons.Filled.CheckCircle, contentDescription = "Verified developer", tint = Accent, modifier = Modifier.size(18.dp))
                    }
                    Text("Brand: ${DeveloperInfo.BRAND}", color = Accent, style = MaterialTheme.typography.titleMedium)
                    Text(DeveloperInfo.ROLE, style = MaterialTheme.typography.bodyMedium)
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Icon(Icons.Filled.LocationOn, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(16.dp))
                        Text(DeveloperInfo.LOCATION, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Text(
                        DeveloperInfo.BIO,
                        style = MaterialTheme.typography.bodySmall,
                        textAlign = TextAlign.Center,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.85f),
                    )
                }
            }
        }

        // Skills
        item { SectionLabel("Core expertise") }
        items(DeveloperInfo.skills.size) { i ->
            val s = DeveloperInfo.skills[i]
            AppCard {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(Modifier.size(6.dp).clip(CircleShape).background(Accent))
                    Text(s.name, style = MaterialTheme.typography.titleMedium)
                }
                Text(s.desc, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        // Channels
        item { SectionLabel("Official channels") }
        items(DeveloperInfo.channels.size) { i ->
            val ch = DeveloperInfo.channels[i]
            AppCard(Modifier.clickable { openUrl(context, ch.url) }) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    BadgeText(ch.badge, color = channelColor(ch.badge))
                    Text(ch.title, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                    Text("${ch.action} →", style = MaterialTheme.typography.bodySmall, color = channelColor(ch.badge))
                }
            }
        }

        // Privacy
        item { SectionLabel("Privacy & data") }
        item {
            AppCard {
                Text(
                    "Everything stays on this device. Mat Dekha Ab has no internet permission, collects no " +
                        "social-media credentials and uploads nothing.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                TextButton(onClick = { confirmClear = true }) { Text("Clear usage history", color = Danger) }
            }
        }

        // Honest build status
        item { SectionLabel("Build status") }
        item {
            AppCard {
                StatusRow("Usage tracking", FeatureAvailability.USAGE_TRACKING)
                StatusRow("App blocking", FeatureAvailability.APP_BLOCKING)
                StatusRow("Reels / Shorts detection", FeatureAvailability.REELS_DETECTION)
                StatusRow("Scheduled blocking", FeatureAvailability.SCHEDULED_BLOCKING)
                StatusRow("PIN protection", FeatureAvailability.PIN_PROTECTION)
                Text(
                    "Reels/Shorts detection relies on Instagram/YouTube screen structure and may stop working after " +
                        "their updates. Counts and Reels time are estimates, never exact.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }

        item {
            Text(
                "Mat Dekha Ab ${if (version.isNotBlank()) "v$version" else ""}\n© ${DeveloperInfo.BRAND}",
                modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
                textAlign = TextAlign.Center,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text("Clear usage history?") },
            text = {
                Text(
                    "This deletes the usage history stored by this app. Android keeps its own recent usage " +
                        "records, so today's numbers may reappear after the next refresh."
                )
            },
            confirmButton = {
                TextButton(onClick = { vm.clearHistory(); confirmClear = false }) { Text("Clear", color = Danger) }
            },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun StatusRow(name: String, status: FeatureStatus) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        Text(name, style = MaterialTheme.typography.bodyMedium)
        when (status) {
            FeatureStatus.Implemented -> Pill(status.label, Success)
            FeatureStatus.Experimental -> Pill(status.label, Warning)
            FeatureStatus.NotYet -> Pill(status.label, Color(0xFF94A3B8))
        }
    }
}

private fun channelColor(badge: String): Color = when (badge) {
    "YT" -> Color(0xFFFF3B3B)
    "IG" -> Color(0xFFE1306C)
    "TG" -> Color(0xFF2AABEE)
    "WA" -> Color(0xFF25D366)
    else -> Accent
}

/** Developer portrait inside a slowly rotating brand-colour ring. */
@Composable
private fun DevAvatar() {
    val transition = rememberInfiniteTransition(label = "ring")
    val angle by transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(4000, easing = LinearEasing), RepeatMode.Restart),
        label = "angle",
    )
    Box(
        Modifier
            .size(132.dp)
            .drawBehind {
                val stroke = 5.dp.toPx()
                rotate(angle) {
                    drawCircle(
                        brush = Brush.sweepGradient(listOf(Color.Transparent, Accent, Color(0xFFFF8A3D), Color.Transparent)),
                        radius = size.minDimension / 2 - stroke / 2,
                        style = Stroke(width = stroke),
                    )
                }
            }
            .padding(10.dp),
        contentAlignment = Alignment.Center,
    ) {
        Image(
            painter = painterResource(R.drawable.dev_avatar),
            contentDescription = "Developer portrait",
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .fillMaxSize()
                .clip(CircleShape)
                .border(1.dp, Line, CircleShape),
        )
    }
}

private fun openUrl(context: Context, url: String) {
    try {
        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (ignored: ActivityNotFoundException) { /* no browser installed */ }
}
