# Mat Dekha Ab v0.6.0 (v7) - "Signal" UI redesign

## New look
- Design language built from the new logo: ink black, signal red, white, mint green. Flat surfaces + hairline borders (no glass, gold, particles or shimmer).
- Plain modern sans-serif type with big tabular numbers (condensed gold headings removed).
- Docked bottom navigation bar with labels and a soft red pill on the active tab (replaces the floating gold pill).
- Home: big screen-time number, "% above/below your average" chip, budget bar, slim weekly bars, one grouped "Most used today" card.
- Solid red primary buttons, green switches/status for "on", flat stat tiles.

## Logo fit
- New logo added: `ic_logo.png` (full logo, white corners removed -> transparent rounded square), `ic_emblem.png` (phone + timer emblem, used in header tiles and the Blocked screen).
- Launcher icon rebuilt from the emblem (adaptive icon: black background + emblem in the safe zone).
- About screen shows the full logo.

## Other
- Emojis removed from messages for a cleaner, professional tone.
- versionName 0.6.0 / versionCode 4.
