package com.matdekhaab.ui

import org.junit.Assert.assertEquals
import org.junit.Test

class FormatTest {
    @Test fun durations() {
        assertEquals("0m", formatDuration(0))
        assertEquals("<1m", formatDuration(30_000))
        assertEquals("45m", formatDuration(45 * 60_000L))
        assertEquals("2h 5m", formatDuration(125 * 60_000L))
    }

    @Test fun minutes() {
        assertEquals("5m", formatMinutes(5))
        assertEquals("1h", formatMinutes(60))
        assertEquals("1h 30m", formatMinutes(90))
        assertEquals("2h", formatMinutes(120))
    }
}
