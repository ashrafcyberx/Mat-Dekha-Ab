package com.matdekhaab.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class LimitEngineTest {
    @Test fun remainingCountsDown() {
        assertEquals(10 * 60_000L, LimitEngine.remainingMs(15, 5 * 60_000L))
    }

    @Test fun neverNegative() {
        assertEquals(0L, LimitEngine.remainingMs(5, 99 * 60_000L))
    }

    @Test fun exceededAtExactLimit() {
        assertTrue(LimitEngine.isExceeded(30, 30 * 60_000L))
        assertFalse(LimitEngine.isExceeded(30, 30 * 60_000L - 1))
    }
}
