package com.matdekhaab.data.usage

import com.matdekhaab.data.usage.ForegroundSessionCalculator.PAUSED
import com.matdekhaab.data.usage.ForegroundSessionCalculator.RESUMED
import com.matdekhaab.data.usage.ForegroundSessionCalculator.SCREEN_NON_INTERACTIVE
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class ForegroundSessionCalculatorTest {
    private val a = "com.example.a"
    private val b = "com.example.b"
    private fun ev(p: String, type: Int, t: Long) = RawUsageEvent(p, type, t)
    private fun run(vararg e: RawUsageEvent) = ForegroundSessionCalculator.compute(e.toList(), 0, 100_000)

    @Test fun simpleSession() {
        val r = run(ev(a, RESUMED, 1_000), ev(a, PAUSED, 5_000))
        assertEquals(4_000, r[a]!!.foregroundMs)
        assertEquals(1, r[a]!!.launchCount)
    }

    @Test fun inAppActivitySwitchIsNotANewLaunch() {
        val r = run(
            ev(a, RESUMED, 1_000), ev(a, PAUSED, 5_000),
            ev(a, RESUMED, 5_100), ev(a, PAUSED, 8_000),
        )
        assertEquals(6_900, r[a]!!.foregroundMs)
        assertEquals(1, r[a]!!.launchCount)
    }

    @Test fun separateLaunchesCountTwice() {
        val r = run(
            ev(a, RESUMED, 1_000), ev(a, PAUSED, 2_000),
            ev(b, RESUMED, 2_000), ev(b, PAUSED, 9_000),
            ev(a, RESUMED, 20_000), ev(a, PAUSED, 21_000),
        )
        assertEquals(2_000, r[a]!!.foregroundMs)
        assertEquals(2, r[a]!!.launchCount)
        assertEquals(7_000, r[b]!!.foregroundMs)
    }

    @Test fun openSessionIsClosedAtWindowEnd() {
        assertEquals(10_000, run(ev(a, RESUMED, 90_000))[a]!!.foregroundMs)
    }

    @Test fun appAlreadyForegroundAtWindowStart() {
        val r = run(ev(a, PAUSED, 3_000))
        assertEquals(3_000, r[a]!!.foregroundMs)
        assertEquals(0, r[a]!!.launchCount)
    }

    @Test fun screenOffClosesSession() {
        val r = run(ev(a, RESUMED, 1_000), ev("", SCREEN_NON_INTERACTIVE, 4_000))
        assertEquals(3_000, r[a]!!.foregroundMs)
    }

    @Test fun noEventsMeansNoUsage() {
        assertNull(run()[a])
    }
}
