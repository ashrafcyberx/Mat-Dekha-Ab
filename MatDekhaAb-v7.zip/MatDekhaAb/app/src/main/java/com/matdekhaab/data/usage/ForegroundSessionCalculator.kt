package com.matdekhaab.data.usage

import com.matdekhaab.domain.AppUsage

data class RawUsageEvent(val packageName: String, val type: Int, val timeMs: Long)

/**
 * Pure function: turns UsageEvents into per-app foreground time + launch counts.
 * No Android classes, so it is unit-testable on the JVM.
 *
 * Rules:
 *  - Time counts only between ACTIVITY_RESUMED and ACTIVITY_PAUSED/STOPPED (no background time).
 *  - Screen-off and device shutdown close every open session.
 *  - An app already foreground at window start (first event is PAUSED/STOPPED) counts from window start.
 *  - A PAUSED->RESUMED gap <= CONTINUATION_GAP_MS in the same package is an in-app activity
 *    switch, not a new launch.
 *
 * Known approximations: some OEMs omit SCREEN_NON_INTERACTIVE; "launch count" means
 * foreground entries, which can differ slightly from what a user perceives as a launch.
 */
object ForegroundSessionCalculator {
    // UsageEvents.Event values. Newer ones simply never occur on older Android versions.
    const val RESUMED = 1                  // ACTIVITY_RESUMED / MOVE_TO_FOREGROUND
    const val PAUSED = 2                   // ACTIVITY_PAUSED / MOVE_TO_BACKGROUND
    const val STOPPED = 23                 // ACTIVITY_STOPPED
    const val SCREEN_NON_INTERACTIVE = 16
    const val DEVICE_SHUTDOWN = 26
    const val CONTINUATION_GAP_MS = 1_000L

    fun compute(
        events: List<RawUsageEvent>,
        windowStartMs: Long,
        windowEndMs: Long,
    ): Map<String, AppUsage> {
        val openSince = HashMap<String, Long>()
        val lastEnd = HashMap<String, Long>()
        val seen = HashSet<String>()
        val totals = HashMap<String, Long>()
        val launches = HashMap<String, Int>()

        fun close(pkg: String, at: Long) {
            val start = openSince.remove(pkg) ?: return
            val end = at.coerceIn(start, windowEndMs)
            totals.merge(pkg, end - start, Long::plus)
            lastEnd[pkg] = end
        }

        for (e in events.sortedBy { it.timeMs }) {
            val t = e.timeMs.coerceIn(windowStartMs, windowEndMs)
            val pkg = e.packageName
            when (e.type) {
                RESUMED -> if (pkg.isNotEmpty()) {
                    if (pkg !in openSince) {
                        val prevEnd = lastEnd[pkg]
                        if (prevEnd == null || t - prevEnd > CONTINUATION_GAP_MS) {
                            launches.merge(pkg, 1, Int::plus)
                        }
                        openSince[pkg] = t
                    }
                    seen += pkg
                }
                PAUSED, STOPPED -> if (pkg.isNotEmpty()) {
                    if (pkg in openSince) {
                        close(pkg, t)
                    } else if (seen.add(pkg)) {
                        // Already in foreground when the window began.
                        totals.merge(pkg, t - windowStartMs, Long::plus)
                        lastEnd[pkg] = t
                    }
                }
                SCREEN_NON_INTERACTIVE, DEVICE_SHUTDOWN ->
                    openSince.keys.toList().forEach { close(it, t) }
            }
        }
        openSince.keys.toList().forEach { close(it, windowEndMs) }

        return (totals.keys + launches.keys).associateWith { pkg ->
            AppUsage(pkg, totals[pkg] ?: 0L, launches[pkg] ?: 0)
        }.filterValues { it.foregroundMs > 0 || it.launchCount > 0 }
    }
}
