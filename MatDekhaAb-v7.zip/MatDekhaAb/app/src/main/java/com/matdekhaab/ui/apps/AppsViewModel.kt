package com.matdekhaab.ui.apps

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.matdekhaab.core.AppContainer
import com.matdekhaab.domain.InstalledApp
import com.matdekhaab.service.BlockerService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class AppItem(
    val packageName: String,
    val label: String,
    val selected: Boolean,
    val limitMin: Int?,
    val usedMs: Long,
)

class AppsViewModel(private val c: AppContainer) : ViewModel() {
    private val apps = MutableStateFlow<List<InstalledApp>>(emptyList())
    val query = MutableStateFlow("")
    val loading = MutableStateFlow(true)
    val serviceOn: StateFlow<Boolean> = BlockerService.connected
    val accessGranted: StateFlow<Boolean> = c.usageAccess.granted

    val items: StateFlow<List<AppItem>> = combine(
        apps, query, c.trackedApps.trackedPackages, c.settings.settings, c.usageRepository.observeToday()
    ) { list, q, tracked, s, usage ->
        val used = usage.associate { it.packageName to it.foregroundMs }
        list.filter { q.isBlank() || it.label.contains(q, ignoreCase = true) }
            .map {
                AppItem(
                    packageName = it.packageName,
                    label = it.label,
                    selected = it.packageName in tracked,
                    limitMin = s.appLimitsMin[it.packageName],
                    usedMs = used[it.packageName] ?: 0L,
                )
            }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val selectedCount: StateFlow<Int> = c.trackedApps.trackedPackages.map { it.size }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0)

    init {
        viewModelScope.launch {
            apps.value = c.installedApps.launchableApps()
            loading.value = false
        }
    }

    fun setQuery(q: String) { query.value = q }

    fun toggle(packageName: String, on: Boolean) {
        viewModelScope.launch {
            c.trackedApps.setTracked(packageName, on)
            if (!on) c.settings.setAppLimit(packageName, null)
        }
    }

    fun setLimit(packageName: String, min: Int?) {
        viewModelScope.launch { c.settings.setAppLimit(packageName, min) }
    }
}
