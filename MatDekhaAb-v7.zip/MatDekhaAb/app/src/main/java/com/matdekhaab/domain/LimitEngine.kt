package com.matdekhaab.domain

/** Pure time-limit math (limits are whole minutes per day). */
object LimitEngine {
    fun limitMs(limitMin: Int): Long = limitMin * 60_000L
    fun remainingMs(limitMin: Int, usedMs: Long): Long = (limitMs(limitMin) - usedMs).coerceAtLeast(0L)
    fun isExceeded(limitMin: Int, usedMs: Long): Boolean = remainingMs(limitMin, usedMs) == 0L
}
