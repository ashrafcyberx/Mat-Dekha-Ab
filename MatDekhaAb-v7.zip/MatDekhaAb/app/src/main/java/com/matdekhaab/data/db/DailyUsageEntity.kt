package com.matdekhaab.data.db

import androidx.room.Entity

@Entity(tableName = "daily_usage", primaryKeys = ["epochDay", "packageName"])
data class DailyUsageEntity(
    val epochDay: Long,
    val packageName: String,
    val foregroundMs: Long,
    val launchCount: Int,
    val updatedAtMs: Long,
)

data class DayTotalRow(val epochDay: Long, val totalMs: Long)
