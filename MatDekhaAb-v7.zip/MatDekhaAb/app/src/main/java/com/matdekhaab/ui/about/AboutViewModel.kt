package com.matdekhaab.ui.about

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.matdekhaab.core.AppContainer
import kotlinx.coroutines.launch

class AboutViewModel(private val c: AppContainer) : ViewModel() {
    fun clearHistory() {
        viewModelScope.launch { c.usageRepository.clearHistory() }
    }
}
