package com.matdekhaab.ui.components

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext

/** Prominent disclosure shown BEFORE sending the user to Accessibility settings. */
@Composable
fun AccessibilityCard(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    StatusBanner(
        title = "Turn on the blocking service",
        body = "Limits and blockers need Android's Accessibility service. It is used only to see which app " +
            "is open and, on Instagram and YouTube, to check the screen layout for Reels/Shorts. It does not " +
            "read your messages, passwords or typed text, and nothing leaves your device. You can switch it " +
            "off any time in Settings → Accessibility.",
        modifier = modifier,
        extra = {
            GradientButton(
                text = "Open Accessibility settings",
                onClick = {
                    runCatching {
                        context.startActivity(
                            Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    }
                },
                modifier = Modifier.fillMaxWidth(),
            )
            Text(
                "Find Mat Dekha Ab under Installed/Downloaded apps and turn it on. If the switch is greyed out " +
                    "(Android 13+): long-press the app icon → App info → ⋮ menu → Allow restricted settings, then try again.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        },
    )
}
