package com.matdekhaab.work

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.matdekhaab.MatDekhaApp
import com.matdekhaab.domain.SyncResult
import java.util.concurrent.TimeUnit

class UsageSyncWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        val container = (applicationContext as MatDekhaApp).container
        return when (container.usageRepository.syncNow()) {
            is SyncResult.Failure -> Result.retry()
            else -> Result.success() // PermissionMissing isn't retryable; the UI should prompt the user.
        }
    }
}

object UsageSyncScheduler {
    private const val NAME = "usage_sync"

    /** 15 min is WorkManager's minimum period. Work persists across reboot and app updates. */
    fun schedule(context: Context) {
        val request = PeriodicWorkRequestBuilder<UsageSyncWorker>(15, TimeUnit.MINUTES).build()
        WorkManager.getInstance(context)
            .enqueueUniquePeriodicWork(NAME, ExistingPeriodicWorkPolicy.KEEP, request)
    }
}
