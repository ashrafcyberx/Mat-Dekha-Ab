package com.matdekhaab.data.db

import androidx.room.Dao
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Upsert
import kotlinx.coroutines.flow.Flow

@Dao
abstract class DailyUsageDao {
    @Query("SELECT * FROM daily_usage WHERE epochDay = :day ORDER BY foregroundMs DESC")
    abstract fun observeDay(day: Long): Flow<List<DailyUsageEntity>>

    @Query("SELECT * FROM daily_usage WHERE epochDay BETWEEN :start AND :end")
    abstract suspend fun getRange(start: Long, end: Long): List<DailyUsageEntity>

    @Query(
        "SELECT epochDay, SUM(foregroundMs) AS totalMs FROM daily_usage " +
            "WHERE epochDay BETWEEN :start AND :end GROUP BY epochDay ORDER BY epochDay"
    )
    abstract fun observeDailyTotals(start: Long, end: Long): Flow<List<DayTotalRow>>

    @Query("SELECT COUNT(*) FROM daily_usage WHERE epochDay = :day")
    abstract suspend fun countForDay(day: Long): Int

    @Query("DELETE FROM daily_usage WHERE epochDay = :day")
    abstract suspend fun deleteDay(day: Long)

    @Query("DELETE FROM daily_usage WHERE epochDay < :beforeDay")
    abstract suspend fun deleteBefore(beforeDay: Long)

    @Query("DELETE FROM daily_usage")
    abstract suspend fun clearAll()

    @Upsert
    abstract suspend fun upsertAll(rows: List<DailyUsageEntity>)

    @Transaction
    open suspend fun replaceDay(day: Long, rows: List<DailyUsageEntity>) {
        deleteDay(day)
        upsertAll(rows)
    }
}
