package com.matdekhaab.service

import android.view.accessibility.AccessibilityNodeInfo
import com.matdekhaab.domain.ShortForm

/**
 * EXPERIMENTAL, UNTESTED across app versions. Android has no official "user is watching Reels" API,
 * so this inspects only view resource-ids and selected/visible state (never text or messages).
 * Instagram and YouTube can rename these ids in any update; then detection silently stops working.
 * Update the id lists below if that happens. Full-app blocking is the reliable fallback.
 *
 * Each id lookup is one IPC call, so keep these lists short and ordered most-likely-first.
 */
object ShortFormDetector {
    const val INSTAGRAM = "com.instagram.android"
    const val YOUTUBE = "com.google.android.youtube"

    private val INSTAGRAM_REELS_VIEWER_IDS = listOf(
        "$INSTAGRAM:id/clips_viewer_view_pager",
        "$INSTAGRAM:id/clips_viewer_container",
        "$INSTAGRAM:id/root_clips_layout",
        "$INSTAGRAM:id/clips_swipe_refresh_container",
    )
    private val INSTAGRAM_REELS_TAB_IDS = listOf("$INSTAGRAM:id/clips_tab")
    private val YOUTUBE_SHORTS_IDS = listOf(
        "$YOUTUBE:id/reel_recycler",
        "$YOUTUBE:id/reel_player_page_container",
        "$YOUTUBE:id/reel_watch_fragment_root",
    )

    fun isShortFormApp(pkg: String) = pkg == INSTAGRAM || pkg == YOUTUBE

    /** [root] must already belong to [pkg]; the service checks that before calling. */
    fun detect(root: AccessibilityNodeInfo, pkg: String): ShortForm? = try {
        when (pkg) {
            INSTAGRAM -> if (instagramInReels(root)) ShortForm.InstagramReels else null
            YOUTUBE -> if (anyVisible(root, YOUTUBE_SHORTS_IDS)) ShortForm.YouTubeShorts else null
            else -> null
        }
    } catch (ignored: Exception) {
        null
    }

    private fun instagramInReels(root: AccessibilityNodeInfo): Boolean =
        anyVisible(root, INSTAGRAM_REELS_VIEWER_IDS) ||
            INSTAGRAM_REELS_TAB_IDS.any { id ->
                root.findAccessibilityNodeInfosByViewId(id)?.any { it.isSelected } == true
            }

    private fun anyVisible(root: AccessibilityNodeInfo, ids: List<String>): Boolean =
        ids.any { id -> root.findAccessibilityNodeInfosByViewId(id)?.any { it.isVisibleToUser } == true }
}
