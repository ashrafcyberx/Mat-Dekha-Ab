package com.matdekhaab.core

enum class FeatureStatus(val label: String) {
    Implemented("Implemented"),
    Experimental("Experimental"),
    NotYet("Not yet"),
}

/** Single source of truth for what this build contains. The About screen reads it. */
object FeatureAvailability {
    val USAGE_TRACKING = FeatureStatus.Implemented
    val APP_BLOCKING = FeatureStatus.Implemented
    val REELS_DETECTION = FeatureStatus.Experimental
    val SCHEDULED_BLOCKING = FeatureStatus.NotYet
    val PIN_PROTECTION = FeatureStatus.NotYet
}
