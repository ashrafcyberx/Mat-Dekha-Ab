package com.matdekhaab.domain

import kotlinx.coroutines.flow.Flow

/** User-chosen restriction settings. A limit of 0 means "no limit". */
data class RestrictionSettings(
    val instagramReelsBlock: Boolean = false,
    val instagramReelsLimitMin: Int = 0,
    val youtubeShortsBlock: Boolean = false,
    val youtubeShortsLimitMin: Int = 0,
    val appLimitsMin: Map<String, Int> = emptyMap(),
)

enum class ShortForm { InstagramReels, YouTubeShorts }

/** Reel/Shorts counts are ALWAYS estimates (detected via screen events), never exact measurements. */
data class ReelStats(val instagramReels: Int, val youtubeShorts: Int)

interface ReelStatsRepository {
    /** null = counting is not available/active. */
    fun observeToday(): Flow<ReelStats?>
}
