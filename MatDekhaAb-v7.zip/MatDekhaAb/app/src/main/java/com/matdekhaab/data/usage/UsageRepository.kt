package com.matdekhaab.data.usage

import com.matdekhaab.core.TimeProvider
import com.matdekhaab.core.startMs
import com.matdekhaab.core.today
import com.matdekhaab.data.apps.InstalledAppsRepository
import com.matdekhaab.data.db.DailyUsageDao
import com.matdekhaab.data.db.DailyUsageEntity
import com.matdekhaab.data.settings.TrackedAppsStore
import com.matdekhaab.domain.AppUsage
import com.matdekhaab.domain.DailyTotal
import com.matdekhaab.domain.SyncResult
import com.matdekhaab.domain.UsageSummary
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import java.time.LocalDate
import java.time.YearMonth

/**
 * Single entry point for the UI. All values are MEASURED foreground time of launchable apps.
 * "Total screen time" = sum of foreground time of launchable apps (not screen-on time).
 */
class UsageRepository(
    private val source: UsageStatsSource,
    private val dao: DailyUsageDao,
    private val installedApps: InstalledAppsRepository,
    private val time: TimeProvider,
    private val access: UsageAccessChecker,
    private val tracked: TrackedAppsStore,
) {
    /** Emits today's date now and again after local midnight (zone changes picked up on next tick). */
    fun currentDate(): Flow<LocalDate> = flow {
        while (true) {
            val zone = time.zone()
            val today = time.today()
            emit(today)
            val nextMidnight = today.plusDays(1).startMs(zone)
            delay((nextMidnight - time.nowMs()).coerceIn(1_000L, 3_600_000L))
        }
    }.distinctUntilChanged()

    @OptIn(ExperimentalCoroutinesApi::class)
    fun observeToday(): Flow<List<AppUsage>> =
        currentDate().flatMapLatest { d ->
            dao.observeDay(d.toEpochDay()).map { rows -> rows.map { it.toModel() } }
        }

    /** Today's usage for the apps the user selected. */
    fun observeTodayTracked(): Flow<List<AppUsage>> =
        combine(observeToday(), tracked.trackedPackages) { usage, set ->
            usage.filter { it.packageName in set }
        }

    fun observeTodayTotalMs(): Flow<Long> = observeToday().map { list -> list.sumOf { it.foregroundMs } }

    fun observeTodayFor(packageName: String): Flow<AppUsage> =
        observeToday().map { list ->
            list.firstOrNull { it.packageName == packageName } ?: AppUsage(packageName, 0, 0)
        }

    /**
     * Reads UsageStatsManager events for yesterday (final pass) and today and stores them.
     * Safe to call often; call from onResume and from the periodic worker.
     */
    suspend fun syncNow(): SyncResult = withContext(Dispatchers.IO) {
        if (!access.refresh()) return@withContext SyncResult.PermissionMissing
        try {
            val zone = time.zone()
            val now = time.nowMs()
            val today = time.today()
            val launchable = installedApps.launchableApps().map { it.packageName }.toSet()
            var written = 0
            for (date in listOf(today.minusDays(1), today)) {
                val start = date.startMs(zone)
                val end = minOf(now, date.plusDays(1).startMs(zone))
                if (end <= start) continue
                val usage = ForegroundSessionCalculator.compute(source.queryEvents(start, end), start, end)
                val rows = usage.values
                    .filter { it.packageName in launchable }
                    .map { DailyUsageEntity(date.toEpochDay(), it.packageName, it.foregroundMs, it.launchCount, now) }
                // Never wipe a stored day with an empty result (e.g. the system dropped old events).
                if (rows.isEmpty() && dao.countForDay(date.toEpochDay()) > 0) continue
                dao.replaceDay(date.toEpochDay(), rows)
                written += rows.size
            }
            dao.deleteBefore(today.minusDays(RETENTION_DAYS).toEpochDay())
            SyncResult.Success(written)
        } catch (ignored: SecurityException) {
            SyncResult.PermissionMissing
        } catch (e: Exception) {
            SyncResult.Failure(e)
        }
    }

    /** LIVE measured foreground time today for one app (reads events now; used by the blocker). */
    suspend fun usedTodayMs(packageName: String): Long = withContext(Dispatchers.IO) {
        val start = time.today().startMs(time.zone())
        val now = time.nowMs()
        ForegroundSessionCalculator.compute(source.queryEvents(start, now), start, now)[packageName]?.foregroundMs ?: 0L
    }

    suspend fun summary(start: LocalDate, endInclusive: LocalDate): UsageSummary = withContext(Dispatchers.IO) {
        require(!endInclusive.isBefore(start)) { "end before start" }
        val rows = dao.getRange(start.toEpochDay(), endInclusive.toEpochDay())
        val byDay = rows.groupBy { it.epochDay }.mapValues { (_, r) -> r.sumOf { it.foregroundMs } }
        val days = generateSequence(start) { it.plusDays(1) }.takeWhile { !it.isAfter(endInclusive) }.toList()
        val totals = days.map { DailyTotal(it, byDay[it.toEpochDay()] ?: 0L) }
        val total = totals.sumOf { it.totalMs }
        val top = rows.groupBy { it.packageName }
            .map { (pkg, r) -> AppUsage(pkg, r.sumOf { it.foregroundMs }, r.sumOf { it.launchCount }) }
            .sortedByDescending { it.foregroundMs }
            .take(10)
        UsageSummary(start, endInclusive, total, total / days.size, totals, top)
    }

    /** Last 7 days ending on [endInclusive] (default: today). */
    suspend fun weeklySummary(endInclusive: LocalDate = time.today()): UsageSummary =
        summary(endInclusive.minusDays(6), endInclusive)

    suspend fun monthlySummary(month: YearMonth): UsageSummary =
        summary(month.atDay(1), month.atEndOfMonth())

    suspend fun clearHistory() = withContext(Dispatchers.IO) { dao.clearAll() }

    private fun DailyUsageEntity.toModel() = AppUsage(packageName, foregroundMs, launchCount)

    companion object { const val RETENTION_DAYS = 400L }
}
