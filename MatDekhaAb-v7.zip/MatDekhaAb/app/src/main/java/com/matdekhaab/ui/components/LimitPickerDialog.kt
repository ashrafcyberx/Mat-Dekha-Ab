package com.matdekhaab.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.matdekhaab.ui.formatMinutes
import com.matdekhaab.ui.theme.Accent
import com.matdekhaab.ui.theme.OnAccent

val LIMIT_PRESETS_MIN = listOf(5, 10, 15, 30, 45, 60, 90, 120)

/** Preset limits (5-120 min) or a custom value (1-1440 min). onSave(null) = no limit. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun LimitPickerDialog(
    title: String,
    currentMin: Int?,
    onDismiss: () -> Unit,
    onSave: (Int?) -> Unit,
) {
    var selected by remember { mutableStateOf(currentMin) }
    var custom by remember {
        mutableStateOf(if (currentMin != null && currentMin !in LIMIT_PRESETS_MIN) currentMin.toString() else "")
    }
    val customValue = custom.toIntOrNull()
    val customInvalid = custom.isNotBlank() && (customValue == null || customValue !in 1..1440)
    val chipColors = FilterChipDefaults.filterChipColors(
        selectedContainerColor = Accent,
        selectedLabelColor = OnAccent,
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    "Daily limit",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    LIMIT_PRESETS_MIN.forEach { m ->
                        FilterChip(
                            selected = selected == m && custom.isBlank(),
                            onClick = { selected = m; custom = "" },
                            label = { Text(formatMinutes(m)) },
                            colors = chipColors,
                        )
                    }
                    FilterChip(
                        selected = selected == null && custom.isBlank(),
                        onClick = { selected = null; custom = "" },
                        label = { Text("No limit") },
                        colors = chipColors,
                    )
                }
                OutlinedTextField(
                    value = custom,
                    onValueChange = { v ->
                        custom = v.filter { it.isDigit() }.take(4)
                        custom.toIntOrNull()?.let { selected = it }
                    },
                    label = { Text("Custom (minutes, 1-1440)") },
                    isError = customInvalid,
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                )
            }
        },
        confirmButton = {
            TextButton(
                enabled = !customInvalid,
                onClick = { onSave(if (custom.isNotBlank()) customValue else selected) },
            ) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}
