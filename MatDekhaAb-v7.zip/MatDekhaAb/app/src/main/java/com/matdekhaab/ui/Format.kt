package com.matdekhaab.ui

fun formatDuration(ms: Long): String {
    val m = ms / 60_000
    return when {
        ms <= 0L -> "0m"
        m < 1 -> "<1m"
        m < 60 -> "${m}m"
        else -> "${m / 60}h ${m % 60}m"
    }
}

fun formatMinutes(min: Int): String = when {
    min < 60 -> "${min}m"
    min % 60 == 0 -> "${min / 60}h"
    else -> "${min / 60}h ${min % 60}m"
}
