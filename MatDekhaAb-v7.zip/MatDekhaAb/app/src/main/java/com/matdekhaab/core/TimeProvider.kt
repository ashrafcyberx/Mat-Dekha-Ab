package com.matdekhaab.core

import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

/** Abstracts the clock/zone so time logic is testable and always reads the CURRENT system zone. */
interface TimeProvider {
    fun nowMs(): Long
    fun zone(): ZoneId
}

class SystemTimeProvider : TimeProvider {
    override fun nowMs(): Long = System.currentTimeMillis()
    override fun zone(): ZoneId = ZoneId.systemDefault()
}

fun TimeProvider.today(): LocalDate = Instant.ofEpochMilli(nowMs()).atZone(zone()).toLocalDate()

fun LocalDate.startMs(zone: ZoneId): Long = atStartOfDay(zone).toInstant().toEpochMilli()
