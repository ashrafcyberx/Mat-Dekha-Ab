package com.matdekhaab.data.settings

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map

val Context.settingsDataStore: DataStore<Preferences> by preferencesDataStore(name = "settings")

/** Which apps the user chose to track/restrict. Later stages add limits, schedules, PIN here. */
class TrackedAppsStore(private val store: DataStore<Preferences>) {
    private val key = stringSetPreferencesKey("tracked_packages")

    val trackedPackages: Flow<Set<String>> = store.data.map { it[key] ?: emptySet() }.distinctUntilChanged()

    suspend fun setTracked(packageName: String, tracked: Boolean) {
        store.edit { prefs ->
            val current = prefs[key] ?: emptySet()
            prefs[key] = if (tracked) current + packageName else current - packageName
        }
    }

    suspend fun setAll(packages: Set<String>) {
        store.edit { it[key] = packages }
    }
}
