package com.matdekhaab.ui.home

import android.content.Intent
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.matdekhaab.core.AppContainer
import com.matdekhaab.domain.UsageSummary
import com.matdekhaab.service.BlockerService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class AppRow(val packageName: String, val label: String, val foregroundMs: Long, val launchCount: Int)

class HomeViewModel(private val c: AppContainer) : ViewModel() {
    val accessGranted: StateFlow<Boolean> = c.usageAccess.granted
    val serviceOn: StateFlow<Boolean> = BlockerService.connected
    fun usageSettingsIntents(): List<Intent> = c.usageAccess.settingsIntents()

    private val labels = MutableStateFlow<Map<String, String>>(emptyMap())
    val weekly = MutableStateFlow<UsageSummary?>(null)

    val totalMs: StateFlow<Long> = c.usageRepository.observeTodayTotalMs()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0L)

    val topApps: StateFlow<List<AppRow>> =
        combine(c.usageRepository.observeToday(), labels) { usage, l ->
            usage.sortedByDescending { it.foregroundMs }.take(8).map {
                AppRow(it.packageName, l[it.packageName] ?: it.packageName, it.foregroundMs, it.launchCount)
            }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val trackedCount: StateFlow<Int> = c.trackedApps.trackedPackages.map { it.size }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0)

    init {
        viewModelScope.launch {
            labels.value = c.installedApps.launchableApps().associate { it.packageName to it.label }
        }
    }

    /** Call on every resume: re-checks permission, syncs usage, reloads the weekly chart. */
    fun refresh() {
        viewModelScope.launch {
            c.usageAccess.refresh()
            c.usageRepository.syncNow()
            weekly.value = c.usageRepository.weeklySummary()
        }
    }
}
