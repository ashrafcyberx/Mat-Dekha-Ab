package com.matdekhaab.core

import android.content.Context
import androidx.room.Room
import com.matdekhaab.data.apps.InstalledAppsRepository
import com.matdekhaab.data.db.AppDatabase
import com.matdekhaab.data.reels.ReelStatsStore
import com.matdekhaab.data.settings.RestrictionSettingsStore
import com.matdekhaab.data.settings.TrackedAppsStore
import com.matdekhaab.data.settings.settingsDataStore
import com.matdekhaab.data.usage.UsageAccessChecker
import com.matdekhaab.data.usage.UsageRepository
import com.matdekhaab.data.usage.UsageStatsSource
import com.matdekhaab.domain.ReelStatsRepository

/** Manual dependency container (no DI framework = fewer build problems on a phone). */
class AppContainer(context: Context) {
    private val app = context.applicationContext

    val timeProvider: TimeProvider = SystemTimeProvider()
    val usageAccess = UsageAccessChecker(app)
    val installedApps by lazy { InstalledAppsRepository(app) }
    val trackedApps by lazy { TrackedAppsStore(app.settingsDataStore) }
    val settings by lazy { RestrictionSettingsStore(app.settingsDataStore) }
    val reelStatsStore by lazy { ReelStatsStore(app.settingsDataStore, timeProvider) }
    val reelStats: ReelStatsRepository get() = reelStatsStore

    private val db by lazy {
        Room.databaseBuilder(app, AppDatabase::class.java, "matdekhaab.db").build()
    }

    val usageRepository by lazy {
        UsageRepository(
            source = UsageStatsSource(app),
            dao = db.dailyUsageDao(),
            installedApps = installedApps,
            time = timeProvider,
            access = usageAccess,
            tracked = trackedApps,
        )
    }
}
