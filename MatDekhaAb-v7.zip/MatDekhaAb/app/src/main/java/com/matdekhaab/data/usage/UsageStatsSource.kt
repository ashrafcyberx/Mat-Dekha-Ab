package com.matdekhaab.data.usage

import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context

/** Thin wrapper over UsageStatsManager.queryEvents. Throws SecurityException if access is revoked. */
class UsageStatsSource(private val context: Context) {

    fun queryEvents(startMs: Long, endMs: Long): List<RawUsageEvent> {
        val usm = context.getSystemService(UsageStatsManager::class.java) ?: return emptyList()
        val events = usm.queryEvents(startMs, endMs) ?: return emptyList()
        val out = ArrayList<RawUsageEvent>()
        val e = UsageEvents.Event()
        while (events.hasNextEvent()) {
            events.getNextEvent(e)
            when (e.eventType) {
                ForegroundSessionCalculator.RESUMED,
                ForegroundSessionCalculator.PAUSED,
                ForegroundSessionCalculator.STOPPED,
                ForegroundSessionCalculator.SCREEN_NON_INTERACTIVE,
                ForegroundSessionCalculator.DEVICE_SHUTDOWN ->
                    out += RawUsageEvent(e.packageName ?: "", e.eventType, e.timeStamp)
            }
        }
        return out
    }
}
