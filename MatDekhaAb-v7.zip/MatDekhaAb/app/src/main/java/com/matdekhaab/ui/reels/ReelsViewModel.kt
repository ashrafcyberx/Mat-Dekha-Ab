package com.matdekhaab.ui.reels

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.matdekhaab.core.AppContainer
import com.matdekhaab.domain.ReelStats
import com.matdekhaab.domain.RestrictionSettings
import com.matdekhaab.service.BlockerService
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ReelsViewModel(private val c: AppContainer) : ViewModel() {
    val settings: StateFlow<RestrictionSettings> = c.settings.settings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), RestrictionSettings())

    /** null = counting inactive. Values, when present, are estimates. */
    val serviceOn: StateFlow<Boolean> = BlockerService.connected

    val stats: StateFlow<ReelStats?> =
        combine(c.reelStats.observeToday(), BlockerService.connected) { s, on -> if (on) s else null }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    fun setInstagramBlock(on: Boolean) { viewModelScope.launch { c.settings.setInstagramReelsBlock(on) } }
    fun setInstagramLimit(min: Int?) { viewModelScope.launch { c.settings.setInstagramReelsLimit(min) } }
    fun setYoutubeBlock(on: Boolean) { viewModelScope.launch { c.settings.setYoutubeShortsBlock(on) } }
    fun setYoutubeLimit(min: Int?) { viewModelScope.launch { c.settings.setYoutubeShortsLimit(min) } }
}
