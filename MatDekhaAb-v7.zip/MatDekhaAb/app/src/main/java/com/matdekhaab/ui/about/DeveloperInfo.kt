package com.matdekhaab.ui.about

data class Skill(val name: String, val desc: String)
data class Channel(val badge: String, val title: String, val action: String, val url: String)

/** Developer details (from the Ashraf CyberX branding files). */
object DeveloperInfo {
    const val NAME = "Ashraf Ali"
    const val BRAND = "Ashraf CyberX"
    const val ROLE = "Developer & Designer"
    const val TAG = "Architect & Creator"
    const val LOCATION = "Champaran, Bihar, India"
    const val BIO = "Passionate full-stack developer and UI/UX designer building high-performance " +
        "educational platforms, video streaming pipelines, and clean mobile interfaces for students."

    val skills = listOf(
        Skill("Web Development", "React, Next.js, TypeScript, Cloudflare & Edge APIs"),
        Skill("App Development", "Mobile-first progressive applications, Android & iOS architecture"),
        Skill("UI/UX Design", "Clean interfaces, clear navigation & responsive typography"),
        Skill("Graphic Design", "Brand identity systems, media streaming visuals & vector assets"),
    )

    val channels = listOf(
        Channel("YT", "YouTube Channel", "Visit", "https://youtube.com/@ashraf_cyberx?si=Uw3PAMKLQG_O84zV"),
        Channel("IG", "Instagram Profile", "Visit", "https://www.instagram.com/ashraf_cyberx?stkn=aGEyNG5lZm5namFx"),
        Channel("TG", "Telegram Community", "Join", "https://t.me/Ashraf_CyberX"),
        Channel("WA", "WhatsApp Channel", "Follow", "https://whatsapp.com/channel/0029VbDr1TL8kyyHB4MATv3Q"),
    )
}
