package com.matdekhaab.service

import android.accessibilityservice.AccessibilityService
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.inputmethod.InputMethodManager
import androidx.core.content.ContextCompat
import com.matdekhaab.MatDekhaApp
import com.matdekhaab.core.AppContainer
import com.matdekhaab.core.today
import com.matdekhaab.domain.LimitEngine
import com.matdekhaab.domain.RestrictionSettings
import com.matdekhaab.domain.ShortForm
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Enforcement engine. Uses AccessibilityService ONLY to (1) learn which app is in the foreground and
 * (2) on Instagram/YouTube, check view ids for Reels/Shorts. When a limit is reached it sends the
 * user to the Home screen and shows [BlockedActivity]. It cannot (and does not try to) prevent
 * uninstalling, force-stopping or disabling itself: the user can always switch it off in Settings.
 *
 * Speed notes:
 *  - Reels/Shorts detection runs OFF the main thread, is throttled with a trailing re-check (so the
 *    last event is never dropped) and needs two misses before it decides you left Reels.
 *  - An app that already hit its limit today is remembered, so re-opening it is blocked instantly
 *    without querying UsageStats again.
 *  - Settings/tracked-app flows are de-duplicated, so reel counter writes no longer restart timers.
 */
class BlockerService : AccessibilityService() {

    companion object {
        private val _connected = MutableStateFlow(false)
        val connected: StateFlow<Boolean> = _connected
        private const val SYSTEM_UI = "com.android.systemui"
        private const val DETECT_GAP_IN_SHORTFORM_MS = 300L
        private const val DETECT_GAP_IDLE_MS = 450L
        private const val COUNT_DEBOUNCE_MS = 700L
        private const val EXIT_CONFIRM_MISSES = 2
    }

    /** Result of looking at the screen: [valid] is false when the window isn't the app we expected. */
    private class Reading(val valid: Boolean, val kind: ShortForm?)

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val ioScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private lateinit var container: AppContainer

    private var settings = RestrictionSettings()
    private var tracked: Set<String> = emptySet()
    private var imePackages: Set<String> = emptySet()
    private var currentPkg: String? = null
    private var limitJob: Job? = null
    private var shortFormJob: Job? = null
    private var detectJob: Job? = null
    private var activeKind: ShortForm? = null
    private var activeSince = 0L
    private var lastCountAt = 0L
    private var detectPkg: String? = null
    private var pendingScroll = false
    private var rerun = false
    private var misses = 0
    private var receiverRegistered = false

    /** package -> epoch day on which it already hit its daily limit. */
    private val blockedToday = HashMap<String, Long>()

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                Intent.ACTION_SCREEN_OFF -> {
                    cancelMonitoring()
                    currentPkg = null
                }
                Intent.ACTION_USER_PRESENT -> scope.launch {
                    delay(600)
                    currentPkg = null
                    rootInActiveWindow?.packageName?.toString()?.let { onWindowChanged(it) }
                }
            }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        container = (application as MatDekhaApp).container
        imePackages = runCatching {
            getSystemService(InputMethodManager::class.java).enabledInputMethodList.map { it.packageName }.toSet()
        }.getOrDefault(emptySet())

        if (!receiverRegistered) {
            val filter = IntentFilter().apply {
                addAction(Intent.ACTION_SCREEN_OFF)
                addAction(Intent.ACTION_USER_PRESENT)
            }
            ContextCompat.registerReceiver(this, screenReceiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
            receiverRegistered = true
        }

        scope.launch {
            container.settings.settings.collect { s ->
                settings = s
                blockedToday.clear() // limits may have changed
                currentPkg?.let { evaluateApp(it) }
                activeKind?.let { enforceShortForm(it) }
            }
        }
        scope.launch {
            container.trackedApps.trackedPackages.collect { t ->
                tracked = t
                blockedToday.clear()
                currentPkg?.let { evaluateApp(it) }
            }
        }
        _connected.value = true
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val e = event ?: return
        val pkg = e.packageName?.toString() ?: return
        when (e.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> onWindowChanged(pkg)
            AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED,
            AccessibilityEvent.TYPE_VIEW_SCROLLED -> {
                // Only Instagram/YouTube matter here; everything else returns after one string check.
                if (ShortFormDetector.isShortFormApp(pkg)) {
                    requestDetect(pkg, e.eventType == AccessibilityEvent.TYPE_VIEW_SCROLLED)
                }
            }
        }
    }

    override fun onInterrupt() { /* nothing to interrupt */ }

    override fun onUnbind(intent: Intent?): Boolean {
        _connected.value = false
        cancelMonitoring()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        _connected.value = false
        cancelMonitoring()
        if (receiverRegistered) {
            runCatching { unregisterReceiver(screenReceiver) }
            receiverRegistered = false
        }
        scope.cancel()
        ioScope.cancel()
        super.onDestroy()
    }

    // ---------------------------------------------------------------- app limits

    private fun onWindowChanged(pkg: String) {
        if (pkg == packageName || pkg == SYSTEM_UI || pkg in imePackages) return
        if (pkg == currentPkg) return
        detectJob?.cancel()
        pendingScroll = false
        rerun = false
        switchTo(pkg)
        // Instagram/YouTube may open straight into Reels/Shorts: look right away, don't wait for a scroll.
        if (ShortFormDetector.isShortFormApp(pkg)) requestDetect(pkg, false)
    }

    private fun switchTo(pkg: String) {
        currentPkg = pkg
        limitJob?.cancel()
        exitShortForm()
        evaluateApp(pkg)
    }

    private fun evaluateApp(pkg: String) {
        limitJob?.cancel()
        val limitMin = settings.appLimitsMin[pkg]
        if (pkg !in tracked || limitMin == null) return

        // Already over the limit earlier today: block instantly, no UsageStats query.
        if (blockedToday[pkg] == container.timeProvider.today().toEpochDay()) {
            blockApp(pkg)
            return
        }

        limitJob = scope.launch {
            // If Usage Access was revoked this throws; then we cannot enforce, so we do nothing.
            val used = runCatching { container.usageRepository.usedTodayMs(pkg) }.getOrNull() ?: return@launch
            val remaining = LimitEngine.remainingMs(limitMin, used)
            if (remaining > 0L) delay(remaining)
            if (currentPkg == pkg) blockApp(pkg)
        }
    }

    private fun blockApp(pkg: String) {
        val label = labelOf(pkg)
        blockedToday[pkg] = container.timeProvider.today().toEpochDay()
        currentPkg = null
        performGlobalAction(GLOBAL_ACTION_HOME)
        showBlocked("$label is blocked", "Your daily limit for $label has been reached. It resets at midnight.")
    }

    // ---------------------------------------------------------------- Reels / Shorts (experimental)

    /**
     * Leading + trailing throttle: the first call reads the screen immediately; calls that arrive
     * while a read is in progress or cooling down set [rerun], so exactly one more read follows.
     */
    private fun requestDetect(pkg: String, scrolled: Boolean) {
        if (scrolled) pendingScroll = true
        detectPkg = pkg
        if (detectJob?.isActive == true) {
            rerun = true
            return
        }
        detectJob = scope.launch {
            do {
                rerun = false
                val target = detectPkg ?: break
                val countScroll = pendingScroll
                pendingScroll = false
                val reading = withContext(Dispatchers.Default) { readShortForm(target) }
                if (reading.valid) applyReading(target, reading.kind, countScroll)
                delay(if (activeKind != null) DETECT_GAP_IN_SHORTFORM_MS else DETECT_GAP_IDLE_MS)
            } while (rerun)
        }
    }

    /** Runs on a background thread. Only trusts the window if it really belongs to [target]. */
    private fun readShortForm(target: String): Reading {
        val root = rootInActiveWindow ?: return Reading(false, null)
        if (root.packageName?.toString() != target) return Reading(false, null)
        return Reading(true, ShortFormDetector.detect(root, target))
    }

    private fun applyReading(pkg: String, kind: ShortForm?, scrolled: Boolean) {
        if (currentPkg != pkg) {
            if (kind == null) return // not in Reels and not the tracked app: nothing to do
            switchTo(pkg) // missed the window-change event; catch up
        }
        val now = SystemClock.elapsedRealtime()
        val prev = activeKind
        when {
            kind != null && prev == null -> {
                misses = 0
                enterShortForm(kind, now)
            }
            kind != null && prev == kind -> {
                misses = 0
                if (scrolled && now - lastCountAt > COUNT_DEBOUNCE_MS) {
                    lastCountAt = now
                    ioScope.launch { container.reelStatsStore.addReel(kind) }
                }
            }
            kind != null -> { // jumped between Instagram and YouTube
                exitShortForm()
                enterShortForm(kind, now)
            }
            prev != null -> { // kind == null: confirm twice so a layout hiccup isn't treated as leaving
                misses++
                if (misses >= EXIT_CONFIRM_MISSES) {
                    misses = 0
                    exitShortForm()
                } else {
                    rerun = true
                }
            }
        }
    }

    private fun enterShortForm(kind: ShortForm, now: Long) {
        activeKind = kind
        activeSince = now
        lastCountAt = now
        ioScope.launch { container.reelStatsStore.addReel(kind) }
        enforceShortForm(kind)
    }

    private fun exitShortForm() {
        shortFormJob?.cancel()
        val kind = activeKind ?: return
        val elapsed = SystemClock.elapsedRealtime() - activeSince
        activeKind = null
        misses = 0
        ioScope.launch { container.reelStatsStore.addTime(kind, elapsed) }
    }

    /**
     * Blocker toggle ON + no limit  => blocked immediately.
     * Blocker toggle ON + limit set => allowed until the ESTIMATED time reaches the limit.
     */
    private fun enforceShortForm(kind: ShortForm) {
        shortFormJob?.cancel()
        val (block, limitMin) = when (kind) {
            ShortForm.InstagramReels -> settings.instagramReelsBlock to settings.instagramReelsLimitMin
            ShortForm.YouTubeShorts -> settings.youtubeShortsBlock to settings.youtubeShortsLimitMin
        }
        if (!block) return
        if (limitMin <= 0) { // no limit = block right now, don't even wait for a coroutine hop
            blockShortForm(kind, limitMin)
            return
        }
        shortFormJob = scope.launch {
            val stored = container.reelStatsStore.usedMs(kind)
            val session = SystemClock.elapsedRealtime() - activeSince
            val remaining = LimitEngine.remainingMs(limitMin, stored + session)
            if (remaining > 0L) delay(remaining)
            if (activeKind == kind) blockShortForm(kind, limitMin)
        }
    }

    private fun blockShortForm(kind: ShortForm, limitMin: Int) {
        exitShortForm()
        detectJob?.cancel()
        rerun = false
        currentPkg = null
        performGlobalAction(GLOBAL_ACTION_HOME)
        val name = if (kind == ShortForm.InstagramReels) "Instagram Reels" else "YouTube Shorts"
        val message = if (limitMin <= 0) "You turned on the $name blocker."
        else "Your estimated daily limit of $limitMin min for $name has been reached."
        showBlocked("$name blocked", message)
    }

    // ---------------------------------------------------------------- helpers

    private fun cancelMonitoring() {
        limitJob?.cancel()
        detectJob?.cancel()
        rerun = false
        pendingScroll = false
        exitShortForm()
    }

    private fun labelOf(pkg: String): String = runCatching {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    }.getOrDefault(pkg)

    private fun showBlocked(title: String, message: String) {
        // Best effort: HOME was already performed, so the user is safe even if this launch is refused.
        runCatching {
            startActivity(
                Intent(this, BlockedActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    .putExtra(BlockedActivity.EXTRA_TITLE, title)
                    .putExtra(BlockedActivity.EXTRA_MESSAGE, message)
            )
        }
    }
}
