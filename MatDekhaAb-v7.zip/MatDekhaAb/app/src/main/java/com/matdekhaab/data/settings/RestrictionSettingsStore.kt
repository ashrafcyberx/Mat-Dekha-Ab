package com.matdekhaab.data.settings

import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import com.matdekhaab.domain.RestrictionSettings
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map

/** Persists the user's choices. Enforcement itself is implemented in later stages. */
class RestrictionSettingsStore(private val store: DataStore<Preferences>) {
    private val igBlock = booleanPreferencesKey("ig_reels_block")
    private val igLimit = intPreferencesKey("ig_reels_limit_min")
    private val ytBlock = booleanPreferencesKey("yt_shorts_block")
    private val ytLimit = intPreferencesKey("yt_shorts_limit_min")
    private val appLimits = stringSetPreferencesKey("app_limits") // entries "package=minutes"

    val settings: Flow<RestrictionSettings> = store.data.map { p ->
        RestrictionSettings(
            instagramReelsBlock = p[igBlock] ?: false,
            instagramReelsLimitMin = p[igLimit] ?: 0,
            youtubeShortsBlock = p[ytBlock] ?: false,
            youtubeShortsLimitMin = p[ytLimit] ?: 0,
            appLimitsMin = parse(p[appLimits] ?: emptySet()),
        )
    }.distinctUntilChanged() // reel counters share this DataStore; don't re-emit on every swipe

    suspend fun setInstagramReelsBlock(on: Boolean) { store.edit { it[igBlock] = on } }
    suspend fun setInstagramReelsLimit(min: Int?) { store.edit { it[igLimit] = min ?: 0 } }
    suspend fun setYoutubeShortsBlock(on: Boolean) { store.edit { it[ytBlock] = on } }
    suspend fun setYoutubeShortsLimit(min: Int?) { store.edit { it[ytLimit] = min ?: 0 } }

    /** null or <= 0 removes the limit for that app. */
    suspend fun setAppLimit(packageName: String, min: Int?) {
        store.edit { p ->
            val map = parse(p[appLimits] ?: emptySet()).toMutableMap()
            if (min == null || min <= 0) map.remove(packageName) else map[packageName] = min
            p[appLimits] = map.map { "${it.key}=${it.value}" }.toSet()
        }
    }

    private fun parse(entries: Set<String>): Map<String, Int> =
        entries.mapNotNull { e ->
            val i = e.lastIndexOf('=')
            if (i <= 0) null else e.substring(i + 1).toIntOrNull()?.let { e.substring(0, i) to it }
        }.toMap()
}
