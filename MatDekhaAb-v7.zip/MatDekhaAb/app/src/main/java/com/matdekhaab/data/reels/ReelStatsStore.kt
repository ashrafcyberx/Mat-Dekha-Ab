package com.matdekhaab.data.reels

import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.MutablePreferences
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import com.matdekhaab.core.TimeProvider
import com.matdekhaab.core.today
import com.matdekhaab.domain.ReelStats
import com.matdekhaab.domain.ReelStatsRepository
import com.matdekhaab.domain.ShortForm
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

/**
 * Daily Reels/Shorts counters and estimated time. ALL values here are ESTIMATES derived from
 * screen events; they are never exact measurements. Resets when the local date changes.
 */
class ReelStatsStore(
    private val store: DataStore<Preferences>,
    private val time: TimeProvider,
) : ReelStatsRepository {
    private val dayKey = longPreferencesKey("reel_day")
    private val igCount = intPreferencesKey("reel_ig_count")
    private val ytCount = intPreferencesKey("reel_yt_count")
    private val igMs = longPreferencesKey("reel_ig_ms")
    private val ytMs = longPreferencesKey("reel_yt_ms")

    override fun observeToday(): Flow<ReelStats?> = store.data.map { p ->
        if (p[dayKey] == time.today().toEpochDay()) ReelStats(p[igCount] ?: 0, p[ytCount] ?: 0)
        else ReelStats(0, 0)
    }

    suspend fun addReel(kind: ShortForm) {
        store.edit { p ->
            rollover(p)
            when (kind) {
                ShortForm.InstagramReels -> p[igCount] = (p[igCount] ?: 0) + 1
                ShortForm.YouTubeShorts -> p[ytCount] = (p[ytCount] ?: 0) + 1
            }
        }
    }

    suspend fun addTime(kind: ShortForm, ms: Long) {
        if (ms <= 0) return
        store.edit { p ->
            rollover(p)
            when (kind) {
                ShortForm.InstagramReels -> p[igMs] = (p[igMs] ?: 0L) + ms
                ShortForm.YouTubeShorts -> p[ytMs] = (p[ytMs] ?: 0L) + ms
            }
        }
    }

    /** Estimated time already spent today (0 if the stored day is not today). */
    suspend fun usedMs(kind: ShortForm): Long {
        val p = store.data.first()
        if (p[dayKey] != time.today().toEpochDay()) return 0L
        return when (kind) {
            ShortForm.InstagramReels -> p[igMs] ?: 0L
            ShortForm.YouTubeShorts -> p[ytMs] ?: 0L
        }
    }

    private fun rollover(p: MutablePreferences) {
        val today = time.today().toEpochDay()
        if (p[dayKey] != today) {
            p[dayKey] = today
            p[igCount] = 0; p[ytCount] = 0; p[igMs] = 0L; p[ytMs] = 0L
        }
    }
}
