package com.matdekhaab.ui

import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.viewmodel.compose.viewModel
import com.matdekhaab.MatDekhaApp
import com.matdekhaab.ui.about.AboutScreen
import com.matdekhaab.ui.apps.AppsScreen
import com.matdekhaab.ui.components.AppBackground
import com.matdekhaab.ui.home.HomeScreen
import com.matdekhaab.ui.home.HomeViewModel
import com.matdekhaab.ui.reels.ReelsScreen
import com.matdekhaab.ui.theme.Accent
import com.matdekhaab.ui.theme.Line
import com.matdekhaab.ui.theme.TextMuted
import com.matdekhaab.ui.theme.TextPrimary

private enum class Tab(val label: String, val icon: ImageVector) {
    Home("Home", Icons.Filled.Home),
    Reels("Reels", Icons.Filled.PlayArrow),
    Apps("Apps", Icons.AutoMirrored.Filled.List),
    About("About", Icons.Filled.Info),
}

@Composable
fun AppRoot() {
    val container = (LocalContext.current.applicationContext as MatDekhaApp).container
    val factory = remember { VmFactory(container) }
    val home: HomeViewModel = viewModel(factory = factory)
    var tab by rememberSaveable { mutableStateOf(Tab.Home) }

    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { home.refresh() }

    AppBackground {
        Scaffold(
            containerColor = Color.Transparent,
            bottomBar = {
                FloatingNav(selected = tab, onSelect = { tab = it })
            },
        ) { padding ->
            Box(Modifier.padding(padding)) {
                Crossfade(targetState = tab, animationSpec = tween(160), label = "tabs") { current ->
                    when (current) {
                        Tab.Home -> HomeScreen(home, onOpenAppBlocker = { tab = Tab.Apps })
                        Tab.Reels -> ReelsScreen(viewModel(factory = factory), onOpenAppBlocker = { tab = Tab.Apps })
                        Tab.Apps -> AppsScreen(viewModel(factory = factory))
                        Tab.About -> AboutScreen(viewModel(factory = factory))
                    }
                }
            }
        }
    }
}

/** Docked bottom bar: hairline on top, soft red pill behind the selected icon, label under every icon. */
@Composable
private fun FloatingNav(selected: Tab, onSelect: (Tab) -> Unit) {
    Column(Modifier.fillMaxWidth().background(Color(0xFF0B0C10)).navigationBarsPadding()) {
        Box(Modifier.fillMaxWidth().height(1.dp).background(Line))
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Tab.entries.forEach { t ->
                val on = t == selected
                Column(
                    Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(14.dp))
                        .clickable { onSelect(t) }
                        .padding(vertical = 4.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(3.dp),
                ) {
                    Box(
                        Modifier
                            .size(width = 56.dp, height = 30.dp)
                            .clip(CircleShape)
                            .background(if (on) Accent.copy(alpha = 0.18f) else Color.Transparent),
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(t.icon, contentDescription = t.label, tint = if (on) Accent else TextMuted, modifier = Modifier.size(22.dp))
                    }
                    Text(
                        t.label,
                        color = if (on) TextPrimary else TextMuted,
                        fontWeight = if (on) FontWeight.SemiBold else FontWeight.Medium,
                        fontSize = 11.sp,
                    )
                }
            }
        }
    }
}
