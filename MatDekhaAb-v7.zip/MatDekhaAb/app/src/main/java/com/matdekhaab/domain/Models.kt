package com.matdekhaab.domain

import java.time.LocalDate

/**
 * Measured foreground usage of one app (from UsageStatsManager events).
 * There is deliberately no Reels/Shorts field here: that will be a separate model
 * so estimates can never be mistaken for measurements.
 */
data class AppUsage(
    val packageName: String,
    val foregroundMs: Long,
    val launchCount: Int,
)

data class DailyTotal(val date: LocalDate, val totalMs: Long)

data class UsageSummary(
    val start: LocalDate,
    val endInclusive: LocalDate,
    val totalMs: Long,
    val dailyAverageMs: Long,
    val dailyTotals: List<DailyTotal>,
    val topApps: List<AppUsage>,
)

data class InstalledApp(val packageName: String, val label: String)

sealed interface SyncResult {
    data class Success(val rowsWritten: Int) : SyncResult
    data object PermissionMissing : SyncResult
    data class Failure(val error: Throwable) : SyncResult
}
