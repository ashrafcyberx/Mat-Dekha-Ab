package com.matdekhaab

import android.app.Application
import com.matdekhaab.core.AppContainer
import com.matdekhaab.work.UsageSyncScheduler

class MatDekhaApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
        UsageSyncScheduler.schedule(this)
    }
}
