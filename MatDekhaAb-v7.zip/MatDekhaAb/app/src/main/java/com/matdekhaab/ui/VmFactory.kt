package com.matdekhaab.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.matdekhaab.core.AppContainer
import com.matdekhaab.ui.about.AboutViewModel
import com.matdekhaab.ui.apps.AppsViewModel
import com.matdekhaab.ui.home.HomeViewModel
import com.matdekhaab.ui.reels.ReelsViewModel

class VmFactory(private val c: AppContainer) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        val vm: ViewModel = when {
            modelClass.isAssignableFrom(HomeViewModel::class.java) -> HomeViewModel(c)
            modelClass.isAssignableFrom(AppsViewModel::class.java) -> AppsViewModel(c)
            modelClass.isAssignableFrom(ReelsViewModel::class.java) -> ReelsViewModel(c)
            modelClass.isAssignableFrom(AboutViewModel::class.java) -> AboutViewModel(c)
            else -> throw IllegalArgumentException("Unknown ViewModel: ${modelClass.name}")
        }
        return vm as T
    }
}
